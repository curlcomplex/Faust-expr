#pragma once
#include "stream_population.hpp"
#include <thread>
#include <atomic>
#include <memory>

namespace cym19 {
// Optional execution-only worker strategy. Workers exist before processing.
// They sleep on C++20 atomic wait between jobs; no busy-spinning while idle.
// The caller participates then waits for disjoint modal chunks to complete.
// This is measured as part of the callback; no audio-device guarantee is made.
struct ParallelPool {
 int workers;std::vector<std::thread> threads;
 void* hookContext=nullptr;int(*enterHook)(void*,int)=nullptr;void(*leaveHook)(void*,int)=nullptr;
 std::atomic<int> ready{0};int hookStatus[8]{};
 void stop_and_join()noexcept{stop.store(true,std::memory_order_release);generation.fetch_add(1,std::memory_order_release);generation.notify_all();for(auto&t:threads)if(t.joinable())t.join();}
 std::vector<std::unique_ptr<Population::Scratch>> workspaces;
 std::vector<double> modal;
 std::atomic<uint64_t> workerNews{0};
 std::atomic<uint64_t> generation{0};std::atomic<int> completed{0};std::atomic<bool> stop{false};
 Population*pop=nullptr;int n=0;
 void*customContext=nullptr;void(*customJob)(void*,int)=nullptr;
 ParallelPool(int w,int maxmodes,void*ctx=nullptr,int(*enter)(void*,int)=nullptr,void(*leave)(void*,int)=nullptr):workers(w),hookContext(ctx),enterHook(enter),leaveHook(leave),modal(size_t(maxmodes)*MaxBlock*2){
  if(w<2||w>8)throw std::runtime_error("worker count 2..8");
  for(int i=0;i<w;i++)workspaces.emplace_back(std::make_unique<Population::Scratch>());
  try{
   for(int i=1;i<w;i++)threads.emplace_back([this,i]{worker(i);});
   int n=ready.load(std::memory_order_acquire);while(n<w-1){ready.wait(n,std::memory_order_acquire);n=ready.load(std::memory_order_acquire);}
   for(int i=1;i<w;i++)if(hookStatus[i])throw std::runtime_error("Worker setup failed: "+std::to_string(hookStatus[i]));
  }catch(...){stop_and_join();throw;}
 }
 ~ParallelPool(){stop_and_join();}
 void chunk(int i)noexcept{
  int a=0,b=0;if(!customJob){a=pop->model.partition[workers][i];b=pop->model.partition[workers][i+1];}
#ifdef CYM19_TRACK_NEW
  uint64_t oldcount=audio_allocations;bool oldscope=audio_scope;audio_scope=true;
#endif
  if(customJob)customJob(customContext,i);else pop->range(a,b,n,nullptr,modal.data(),*workspaces[i]);
#ifdef CYM19_TRACK_NEW
  audio_scope=oldscope;workerNews.fetch_add(audio_allocations-oldcount,std::memory_order_relaxed);
#endif
 }
 void worker(int i)noexcept{
  int status=enterHook?enterHook(hookContext,i):0;hookStatus[i]=status;ready.fetch_add(1,std::memory_order_release);ready.notify_one();
  if(status)return;
  uint64_t seen=0;
  for(;;){uint64_t gen=generation.load(std::memory_order_acquire);while(gen==seen&&!stop.load(std::memory_order_acquire)){generation.wait(gen,std::memory_order_acquire);gen=generation.load(std::memory_order_acquire);}
   if(stop.load(std::memory_order_acquire)){if(leaveHook)leaveHook(hookContext,i);return;}seen=gen;chunk(i);completed.fetch_add(1,std::memory_order_release);completed.notify_one();
  }
 }
 // One scheduling barrier for independent complete-population jobs. The
 // owner merges each population/cohort in its original arithmetic order.
 void run_custom(void*context,void(*job)(void*,int))noexcept{
  customContext=context;customJob=job;completed.store(0,std::memory_order_relaxed);
  generation.fetch_add(1,std::memory_order_release);generation.notify_all();chunk(0);
  int done=completed.load(std::memory_order_acquire);while(done<workers-1){completed.wait(done,std::memory_order_acquire);done=completed.load(std::memory_order_acquire);}
  customJob=nullptr;customContext=nullptr;
 }
 int process(Population&p,int count,double*out)noexcept{
  if(count<0||count>MaxBlock||!p.snapshot||!out)return 1;
  std::fill(out,out+count*2,0.);if(!p.active||count==0)return 0;
  for(int j=0;j<count;j++){
   double a=(p.age+j)/double(Rate);p.driftDecay[j]=std::exp(-a/1.8);
   double q=(p.age+j)/double(p.model.knotstep);int lo=std::clamp(int(std::floor(q)),0,p.model.nk-2);p.knotlo[j]=lo;p.fraction[j]=std::clamp(q-lo,0.,1.);
  }
  pop=&p;n=count;completed.store(0,std::memory_order_relaxed);generation.fetch_add(1,std::memory_order_release);generation.notify_all();chunk(0);
  int done=completed.load(std::memory_order_acquire);while(done<workers-1){completed.wait(done,std::memory_order_acquire);done=completed.load(std::memory_order_acquire);}
  // Sum individual modes, not worker partial sums: retain original association.
  for(int m=0;m<p.model.count;m++)for(int j=0;j<count*2;j++)out[j]+=modal[size_t(m)*count*2+j];
  p.age+=count;for(int j=0;j<count*2;j++)if(!std::isfinite(out[j]))return 2;return 0;
 }
};
}
