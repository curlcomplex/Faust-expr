#ifndef CYM19_SCENE_API_H
#define CYM19_SCENE_API_H
#include <stdint.h>
#ifdef __cplusplus
extern "C" {
#endif
/* Opaque pointers must originate from this library. See API.md for ownership,
   array shapes, permitted call threads, sample rate and finite capacity. */
const char* interaction_error(void);
void* cym19_body_create(const double* lo,int nl,const double* hi,int nh,
                       const double* knots,int nk,int knotstep,
                       const double* envtime,const double* envweight,int envcount);
void cym19_body_destroy(void* body);
void* cym19_snapshot_prepare(void* body,const double* controls);
void cym19_snapshot_destroy(void* snapshot);
void* cym19_impact_prepare(void* body,const double* lo,const double* hi,double strength);
void cym19_impact_destroy(void* impact);
void* cym19_scene_create(void* body,int capacity);
int cym19_workers_prepare(void* scene,int workers);
void cym19_scene_destroy(void* scene);
int cym19_install(void* scene,void* snapshot);
int cym19_strike(void* scene,void* impact);
int cym19_process(void* scene,int frames,double* out);
int cym19_reset(void* scene);
int64_t cym19_frame(void* scene);
void cym19_stats(void* scene,uint64_t* fiveCounters);
uint64_t cym19_worker_allocations(void* scene);
int cym19_run_blocks(void* scene,int total,int block,double* out,double* times,int* sizes);
int cym19_run_events(void* scene,int total,int block,const int* eventFrames,
                    const int* eventTypes,void* const* eventData,int eventCount,
                    double* out,double* times,int* sizes);
#ifdef __cplusplus
}
#endif
#endif

#ifdef __cplusplus
extern "C" {
#endif
// Checkpoint-20 execution additions. Old cym19 ABI remains compatible.
const char* cym20_backend_name(void);
// Preparation only, at frame zero. 1 (default) batches independent populations
// across overlapping histories; 0 retains the old per-population worker schedule.
int cym20_overlap_jobs(void* scene, int enabled);
#ifdef __cplusplus
}
#endif

#ifdef __cplusplus
extern "C" {
#endif
int cym21_scheduler_prepare(void* scene,int enabled,int tile,int dynamicGrain,int fixedGrain);
int cym21_profile_enable(void* scene,int enabled);
// 21 doubles: prep,dispatch,reduce,batches,8 worker busy times,8 task counts,bytes.
void cym21_scheduler_stats(void* scene,double* output);
#ifdef __cplusplus
}
#endif

#ifdef __cplusplus
extern "C" {
#endif
// Prepare only, with scene stopped at frame zero. Hooks execute on each auxiliary
// worker, once. Context must outlive the scene/team. Caller belongs to host group.
// enter returns 0 on success, nonzero on failure; leave runs only after success.
int cym21_workers_prepare_hooks(void*,int,void*,int(*)(void*,int),void(*)(void*,int));
#ifdef __cplusplus
}
#endif
