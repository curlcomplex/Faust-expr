// All resonator and material/thickness/contact calculations run through generated Faust.
// This driver supplies numeric modal coefficients, impulse events, controls and prescribed phase wander.
#include <algorithm>
#include <cmath>
#include <cstring>
#include <map>
#include <string>
#include <vector>
#include <stdexcept>
#define FAUSTFLOAT double
struct dsp { virtual ~dsp()=default; };
struct Meta { void declare(const char*,const char*){} };
struct UI {
 std::map<std::string,double*> p;
 void openTabBox(const char*){} void openHorizontalBox(const char*){} void openVerticalBox(const char*){} void closeBox(){}
 void declare(double*,const char*,const char*){}
 void addButton(const char*n,double*v){p[n]=v;} void addCheckButton(const char*n,double*v){p[n]=v;}
 void addVerticalSlider(const char*n,double*v,double,double,double,double){p[n]=v;}
 void addHorizontalSlider(const char*n,double*v,double,double,double,double){p[n]=v;}
 void addNumEntry(const char*n,double*v,double,double,double,double){p[n]=v;}
 void addHorizontalBargraph(const char*,double*,double,double){} void addVerticalBargraph(const char*,double*,double,double){}
 void set(const std::string&n,double v){auto it=p.find(n);if(it!=p.end())*it->second=v;}
};
#include "pole_batch.hpp"
#include "coefficients.hpp"
static const char* locals[]={"f","d","b0","b1","b2","b3","c0","c1","mass_edge","wet0","wet1","wet2","wet3","wet4","hydro"};
static const char* commons[]={"material_a","material_b","material_mix","material_depth","intrinsic_loss_scale","thermal_thickness_mm","thickness_ratio","rim_thickness_ratio","diameter_ratio","temperature_C","thermal_modulus_ratio","immersion","fluid_density","fluid_viscosity","contact_material","contact_pressure","contact_area_cm2","contact_pad_mm","contact_strength","grip","grip_strength","frequency_scale","loss_scale"};
constexpr int NC=23, STRIDE=21, RATE=48000, BLOCK=128;
static thread_local std::string last_error;
extern "C" const char* interaction_error(){return last_error.c_str();}
extern "C" int coefficients(const double* rows,int count,const double* ctr,double* dst){
 try{CoefficientProbe p;p.init(RATE);UI u;p.buildUserInterface(&u);for(int k=0;k<NC;k++)u.set(commons[k],ctr[k]);
  for(int i=0;i<count;i++){u.set("external_excitation",rows[i*STRIDE+20]>0);for(int k=0;k<15;k++)u.set(locals[k],rows[i*STRIDE+k]);double z[5];double* out[5]={z,z+1,z+2,z+3,z+4};p.compute(1,nullptr,out);std::copy(z,z+5,dst+5*i);}return 0;
 }catch(const std::exception&e){last_error=e.what();return 1;}
}


#include "stream_population.hpp"
namespace cym19 {
Snapshot prepare_coefficients(const Model&m,const double* ctr){
 Snapshot s;s.c.resize(m.count);
 InteractionPole p;p.init(RATE);UI ui;p.buildUserInterface(&ui);
 CoefficientProbe c;c.init(RATE);UI cu;c.buildUserInterface(&cu);
 for(int j=0;j<NC;j++){ui.set(commons[j],ctr[j]);cu.set(commons[j],ctr[j]);}
 for(int i=0;i<m.count;i++){
  const double*r=m.rows.data()+size_t(i)*STRIDE;
  for(int j=0;j<15;j++){ui.set(locals[j],r[j]);cu.set(locals[j],r[j]);}
  ui.set("external_excitation",m.kinds[i]>0);cu.set("external_excitation",m.kinds[i]>0);
  p.refreshCoefficients();double cf[6];p.executionCoefficients(cf);
  double z[5];double*zp[5]={z,z+1,z+2,z+3,z+4};c.compute(1,nullptr,zp);
  auto&d=s.c[i];d.hz=cf[0];d.decay=cf[1];d.audible=cf[2];d.force=cf[3];d.wscale=cf[4];d.limit=cf[5];d.sigma=z[1];
  d.atten=std::exp(-std::max(0.,d.sigma-r[1])/RATE);
  double w=d.wscale*std::min<double>(d.limit,std::max<double>(0.,d.hz*(0.+1.)));d.sn=std::sin(w);d.co=std::cos(w);
 }
 return s;
}
}
// Compatibility wrapper to compare the new block processor to checkpoint 18.
extern "C" int render(const double*rows,int count,const double*knot,int nk,int knotstep,
 const double*timeline,const int*changeframes,int changes,int frames,int onset,double*audio,double*pending_report){
 try{
  cym19::Model m(rows,count,knot,nk,knotstep);cym19::Population pop(m);
  std::vector<cym19::Snapshot> snapshots;snapshots.reserve(changes);
  for(int i=0;i<changes;i++)snapshots.push_back(cym19::prepare_coefficients(m,timeline+size_t(i)*NC));
  std::vector<double> force(size_t(count)*4);for(int i=0;i<count;i++)std::copy(rows+size_t(i)*STRIDE+15,rows+size_t(i)*STRIDE+19,force.data()+size_t(i)*4);
  int seg=0,at=0;while(at<frames){
   while(seg+1<changes&&changeframes[seg+1]<=at)++seg;
   pop.set_snapshot(&snapshots[seg]);if(at==onset)pop.strike(force.data());
   int n=std::min(BLOCK,frames-at);if(at<onset)n=std::min(n,onset-at);if(seg+1<changes)n=std::min(n,changeframes[seg+1]-at);
   if(n<1)throw std::runtime_error("Invalid timeline");
   int rc=pop.process(n,audio+size_t(at)*2);if(rc)throw std::runtime_error("process failed");at+=n;
  }
#ifdef CYM_PROFILE
  fprintf(stderr,"Population %d prep %.6f recurrence %.6f sum %.6f\n",count,pop.prep_s,pop.loop_s,pop.sum_s);
#endif
  pop.pending(pending_report);return 0;
 }catch(const std::exception&e){last_error=e.what();return 1;}
}
