// C interface around the persistent full-detail engine. No plug-in wrapper.
// Generated mathematical expressions are not replaced or simplified.
#include "engine_stream.cpp"
#include <cstdlib>
#include <new>
#include <atomic>
#include <climits>


// Count C++ allocations originating in process/strike/control-install for this DSO.
// bind-symbolically-functions keeps these test overrides local to this library on Linux.
static thread_local bool audio_scope=false;
static thread_local uint64_t audio_allocations=0;
void* operator new(std::size_t n){if(audio_scope)++audio_allocations;if(void*p=std::malloc(n?n:1))return p;throw std::bad_alloc();}
void* operator new[](std::size_t n){return ::operator new(n);}
void operator delete(void*p)noexcept{std::free(p);}void operator delete[](void*p)noexcept{std::free(p);}
void operator delete(void*p,std::size_t)noexcept{std::free(p);}void operator delete[](void*p,std::size_t)noexcept{std::free(p);}
void* operator new(std::size_t n,std::align_val_t a){if(audio_scope)++audio_allocations;void*p=nullptr;if(posix_memalign(&p,size_t(a),n?n:1)==0)return p;throw std::bad_alloc();}
void* operator new[](std::size_t n,std::align_val_t a){return ::operator new(n,a);}
void operator delete(void*p,std::align_val_t)noexcept{std::free(p);}void operator delete[](void*p,std::align_val_t)noexcept{std::free(p);}
void operator delete(void*p,std::size_t,std::align_val_t)noexcept{std::free(p);}void operator delete[](void*p,std::size_t,std::align_val_t)noexcept{std::free(p);}

#define CYM19_TRACK_NEW
#include "parallel_pool.hpp"
namespace cym19 {
struct Body {
 Model low,high;
 std::vector<double> times,weights,slopes;
 Body(const double*lo,int nl,const double*hi,int nh,const double*kn,int nk,int ks,const double*et,const double*ew,int ne)
 :low(lo,nl,std::vector<double>(size_t(nl)*2,0).data(),2,ks),high(hi,nh,kn,nk,ks),times(et,et+ne),weights(ew,ew+ne),slopes(ne-1){
  if(ne<2)throw std::runtime_error("Bad envelope");for(int i=0;i<ne;i++)if(!std::isfinite(times[i])||!std::isfinite(weights[i])||(i&&times[i]<=times[i-1]))throw std::runtime_error("Bad envelope");
  for(int i=0;i<ne-1;i++)slopes[i]=(weights[i+1]-weights[i])/(times[i+1]-times[i]);
 }
 double envelope(double age)const noexcept{
  if(age<0||age<times.front())return 0.;if(age>times.back())return weights.back();
  auto it=std::upper_bound(times.begin(),times.end(),age);int i=int(it-times.begin())-1;
  if(i<0)return 0.;if(i==int(times.size())-1||age==times[i])return weights[i];
  return slopes[i]*(age-times[i])+weights[i];
 }
};
struct BodySnapshot {const Body*body;Snapshot low,high;};
struct Impact {
 const Body*body;std::vector<double> low,high;double strength;
 Impact(const Body&b,const double*lo,const double*hi,double s):body(&b),low(lo,lo+size_t(b.low.count)*4),high(hi,hi+size_t(b.high.count)*4),strength(s){
  if(!std::isfinite(s)||s<0||s>1)throw std::runtime_error("Invalid crash-access strength");
  for(double x:low)if(!std::isfinite(x))throw std::runtime_error("Bad low impulse");for(double x:high)if(!std::isfinite(x))throw std::runtime_error("Bad high impulse");
 }
};
struct Cohort {
 alignas(32) double lowOut[MaxBlock*2]{},highOut[MaxBlock*2]{};
 Population low,high;bool active=false;double strength=0;int64_t onset=0;uint64_t id=0;
 Cohort(const Body&b):low(b.low),high(b.high){}
};
struct Scene {
 const Body&body;const BodySnapshot*snap=nullptr;int64_t frame=0;uint64_t serial=0;std::vector<std::unique_ptr<Cohort>> cohorts;
 alignas(32) double lowbuf[MaxBlock*2],highbuf[MaxBlock*2];
 std::unique_ptr<ParallelPool> pool;
 struct Job{Population*pop;double*out;int status=0;};
 Job jobs[128]{};int jobIndex[8][128]{},jobCounts[8]{},jobN=0;
 bool overlapJobs=true;
 // Execution-only range scheduler. Storage is allocated by prepare_ranges(),
 // never by process(). At most rangeTile samples are staged per population.
 struct RangeTask {int job,begin,end;};
 std::vector<double> rangeModal;
 std::vector<RangeTask> rangeTasks;
 size_t rangeOffsets[128]{};
 alignas(64) std::atomic<int> rangeCursor{0};
 int rangeTaskCount=0,rangeJobCount=0,rangeTile=128,dynamicGrain=64,fixedGrain=256;
 bool rangeEnabled=false;int rangeMode=1;int rangePrefixes[128]{};
 int prefix_count(const Model&m)const noexcept{if(rangeMode==1)return m.count;return m.dynamicPrefix;}
 struct alignas(64) WorkerTime {double useful=0;uint64_t tasks=0;};
 WorkerTime rangeWorker[8];
 uint64_t rangeBatches=0;double rangePrep=0,rangeDispatch=0,rangeReduce=0;
 bool rangeProfile=false;
 int prepare_ranges(int enabled,int tile,int dg,int fg){
  if(enabled<0||enabled>2||processing||frame!=0||tile<8||tile>128||tile%8||dg<4||fg<4||dg%4||fg%4)return 1;
  rangeMode=enabled;
  if(enabled){
   size_t modalCount=size_t(prefix_count(body.low)+prefix_count(body.high))*cohorts.size();
   // Bounded allocation; callers see failure instead of callback allocation.
   if(modalCount*size_t(tile)*2>size_t(1536)*1024*1024/sizeof(double))return 1;
   rangeModal.resize(modalCount*size_t(tile)*2);
   rangeTasks.resize(cohorts.size()*size_t((body.low.count+3)/4+(body.high.count+3)/4));
  }
  rangeTile=tile;dynamicGrain=dg;fixedGrain=fg;rangeEnabled=enabled!=0;return 0;
 }
 int process_ranges(int n)noexcept{
  jobN=n;int count=0;size_t offset=0;
  for(auto&c:cohorts)if(c->active&&c->strength>0)jobs[count++]={&c->high,c->highOut,0};
  for(auto&c:cohorts)if(c->active){jobs[count++]={&c->low,c->lowOut,0};if(c->strength==0)std::fill(c->highOut,c->highOut+n*2,0.);}
  auto t0=std::chrono::steady_clock::time_point{};
  if(rangeProfile)t0=std::chrono::steady_clock::now();
  rangeTaskCount=0;rangeJobCount=count;
  for(int j=0;j<count;j++){
   auto&p=*jobs[j].pop;const auto&m=p.model;int prefix=prefix_count(m);rangePrefixes[j]=prefix;rangeOffsets[j]=offset;offset+=size_t(prefix)*n*2;
   if(!prefix){rangeTasks[rangeTaskCount++]={j,-1,-1};continue;}
   for(int k=0;k<n;k++){
    double a=(p.age+k)/double(Rate);p.driftDecay[k]=std::exp(-a/1.8);
    double q=(p.age+k)/double(m.knotstep);int lo=std::clamp(int(std::floor(q)),0,m.nk-2);
    p.knotlo[k]=lo;p.fraction[k]=std::clamp(q-lo,0.,1.);
   }
   for(int a=0;a<prefix;){
    bool dynamic=false;for(int k=a;k<std::min(a+4,m.count);k++)dynamic|=m.kinds[k]==1;
    int b=std::min(prefix,a+(dynamic?dynamicGrain:fixedGrain));
    rangeTasks[rangeTaskCount++]={j,a,b};a=b;
   }
  }
  if(!count)return 0;
  if(rangeMode==2){int head=0;for(int i=0;i<rangeTaskCount;i++)if(rangeTasks[i].begin<0){auto t=rangeTasks[i];for(int j=i;j>head;j--)rangeTasks[j]=rangeTasks[j-1];rangeTasks[head++]=t;}}
  if(rangeProfile){auto t=std::chrono::steady_clock::now();rangePrep+=std::chrono::duration<double>(t-t0).count();t0=t;}
  rangeCursor.store(0,std::memory_order_relaxed);
  pool->run_custom(this,[](void*ctx,int worker)noexcept{
   auto&s=*static_cast<Scene*>(ctx);auto t=std::chrono::steady_clock::time_point{};
   if(s.rangeProfile)t=std::chrono::steady_clock::now();uint64_t done=0;
   for(;;){int k=s.rangeCursor.fetch_add(1,std::memory_order_relaxed);if(k>=s.rangeTaskCount)break;
    auto task=s.rangeTasks[k];auto&p=*s.jobs[task.job].pop;
    if(task.begin<0)s.jobs[task.job].status=p.process(s.jobN,s.jobs[task.job].out);
    else p.range(task.begin,task.end,s.jobN,nullptr,s.rangeModal.data()+s.rangeOffsets[task.job],*s.pool->workspaces[worker]);++done;
   }
   if(s.rangeProfile){s.rangeWorker[worker].useful+=std::chrono::duration<double>(std::chrono::steady_clock::now()-t).count();s.rangeWorker[worker].tasks+=done;}
  });
  if(rangeProfile){auto t=std::chrono::steady_clock::now();rangeDispatch+=std::chrono::duration<double>(t-t0).count();t0=t;}
  // Each population's sequential reduction is independent of other populations.
  // Never reduce worker partial sums: retain every modal addition in order.
  rangeCursor.store(0,std::memory_order_relaxed);
  pool->run_custom(this,[](void*ctx,int worker)noexcept{
   auto&s=*static_cast<Scene*>(ctx);
   for(;;){int k=s.rangeCursor.fetch_add(1,std::memory_order_relaxed);if(k>=s.rangeJobCount)break;
    if(!s.rangePrefixes[k])continue;
    auto&job=s.jobs[k];auto&p=*job.pop;double*modal=s.rangeModal.data()+s.rangeOffsets[k];
    std::fill(job.out,job.out+s.jobN*2,0.);
    for(int m=0;m<s.rangePrefixes[k];m++)for(int j=0;j<s.jobN*2;j++)job.out[j]+=modal[size_t(m)*s.jobN*2+j];
    if(s.rangePrefixes[k]<p.model.count)p.range(s.rangePrefixes[k],p.model.count,s.jobN,job.out,nullptr,*s.pool->workspaces[worker]);
    p.age+=s.jobN;for(int j=0;j<s.jobN*2;j++)if(!std::isfinite(job.out[j]))job.status=2;
   }
  });
  if(rangeProfile)rangeReduce+=std::chrono::duration<double>(std::chrono::steady_clock::now()-t0).count();
  ++rangeBatches;
  for(int j=0;j<count;j++)if(jobs[j].status)return jobs[j].status;return 0;
 }
 int render_ranges(int n,double*out)noexcept{
  int offset=0;
  while(offset<n){int k=std::min(n-offset,rangeTile);int rc=process_ranges(k);if(rc)return rc;
   for(auto&c:cohorts)if(c->active)for(int j=0;j<k;j++){
    double age=(frame+offset+j)/double(Rate)-c->onset/double(Rate);
    double q=std::clamp(c->strength*body.envelope(age),0.,1.);double wl=std::sqrt(1-q),wh=std::sqrt(q);
    out[2*(offset+j)]+=wl*c->lowOut[2*j]+wh*c->highOut[2*j];
    out[2*(offset+j)+1]+=wl*c->lowOut[2*j+1]+wh*c->highOut[2*j+1];
   }
   offset+=k;
  }
  return 0;
 }
 uint64_t processCalls=0,allocs=0,rejectedStrikes=0;int maxActive=0;bool processing=false;
 explicit Scene(const Body&b,int capacity):body(b){
  if(capacity<1||capacity>64)throw std::runtime_error("Capacity must be 1..64; no silent voice stealing");
  cohorts.reserve(capacity);for(int i=0;i<capacity;i++)cohorts.emplace_back(std::make_unique<Cohort>(b));
 }
 int install(const BodySnapshot*s)noexcept{
  if(!s||s->body!=&body)return 1;snap=s;for(auto&c:cohorts){c->low.set_snapshot(&s->low);c->high.set_snapshot(&s->high);}return 0;
 }
 int strike(const Impact*p)noexcept{
  if(!p||p->body!=&body||!snap)return 1;
  for(auto&c:cohorts)if(!c->active){c->low.strike(p->low.data());c->high.strike(p->high.data());c->strength=p->strength;c->onset=frame;c->id=++serial;c->active=true;maxActive=std::max(maxActive,active_count());return 0;}
  ++rejectedStrikes;return 3; // caller must report saturation, never truncate a tail.
 }
 int active_count()const noexcept{int n=0;for(const auto&c:cohorts)n+=int(c->active);return n;}
 void reset()noexcept{for(auto&c:cohorts){c->low.reset();c->high.reset();c->active=false;}frame=0;serial=0;}
 int process_jobs(int n)noexcept{
  jobN=n;int count=0;
  // High populations are heavier: schedule them first, then low populations.
  // This changes scheduling only; population and final summation order are fixed.
  for(auto&c:cohorts)if(c->active&&c->strength>0)jobs[count++]={&c->high,c->highOut,0};
  int highJobs=count;
  for(auto&c:cohorts)if(c->active){jobs[count++]={&c->low,c->lowOut,0};if(c->strength==0)std::fill(c->highOut,c->highOut+n*2,0.);}
  std::fill(jobCounts,jobCounts+8,0);int load[8]{};
  for(int j=0;j<count;j++){int dst=0;for(int w=1;w<pool->workers;w++)if(load[w]<load[dst])dst=w;jobIndex[dst][jobCounts[dst]++]=j;load[dst]+=j<highJobs?3:1;}
  pool->run_custom(this,[](void*ctx,int worker)noexcept{auto&s=*static_cast<Scene*>(ctx);for(int j=0;j<s.jobCounts[worker];j++){auto&job=s.jobs[s.jobIndex[worker][j]];job.status=job.pop->process(s.jobN,job.out);}});
  for(int j=0;j<count;j++)if(jobs[j].status)return jobs[j].status;return 0;
 }
 int process(int n,double*out)noexcept{
  if(n<0||n>MaxBlock||!out||!snap||processing)return 1;
  processing=true;uint64_t before=audio_allocations;audio_scope=true;
  std::fill(out,out+size_t(n)*2,0.);int rc=0;
  if(pool&&rangeEnabled&&n>0){
   rc=render_ranges(n,out);audio_scope=false;allocs+=audio_allocations-before;processing=false;++processCalls;
   if(rc)return rc;for(int j=0;j<n*2;j++)if(!std::isfinite(out[j]))return 2;frame+=n;return 0;
  }
  const bool useJobs=pool&&active_count()>1&&overlapJobs&&n>0;
  if(useJobs)rc=process_jobs(n);
  for(auto&c:cohorts)if(c->active&&!rc){
   double*lo=lowbuf,*hi=highbuf;
   if(useJobs){lo=c->lowOut;hi=c->highOut;}else{
   rc=pool?pool->process(c->low,n,lowbuf):c->low.process(n,lowbuf);if(rc)break;
   if(c->strength>0){rc=pool?pool->process(c->high,n,highbuf):c->high.process(n,highbuf);if(rc)break;}else std::fill(highbuf,highbuf+n*2,0.);
   }
   for(int j=0;j<n;j++){
    // Verbatim checkpoint18 age convention: absolute-time division, THEN subtract
    // onset. Do not replace with relative frames/Rate: that changes rounding.
    double age=(frame+j)/double(Rate)-c->onset/double(Rate);
    double q=std::clamp(c->strength*body.envelope(age),0.,1.);double wl=std::sqrt(1-q),wh=std::sqrt(q);
    out[2*j]+=wl*lo[2*j]+wh*hi[2*j];out[2*j+1]+=wl*lo[2*j+1]+wh*hi[2*j+1];
   }
  }
  audio_scope=false;allocs+=audio_allocations-before;processing=false;++processCalls;
  if(rc)return rc;for(int j=0;j<n*2;j++)if(!std::isfinite(out[j]))return 2;frame+=n;return 0;
 }
};
}
extern "C" {
void* cym19_body_create(const double*lo,int nl,const double*hi,int nh,const double*kn,int nk,int ks,const double*et,const double*ew,int ne){try{return new cym19::Body(lo,nl,hi,nh,kn,nk,ks,et,ew,ne);}catch(const std::exception&e){last_error=e.what();return nullptr;}}
void cym19_body_destroy(void*b){delete static_cast<cym19::Body*>(b);}
void* cym19_snapshot_prepare(void*b,const double*controls){try{auto*body=static_cast<cym19::Body*>(b);return new cym19::BodySnapshot{body,cym19::prepare_coefficients(body->low,controls),cym19::prepare_coefficients(body->high,controls)};}catch(const std::exception&e){last_error=e.what();return nullptr;}}
void cym19_snapshot_destroy(void*p){delete static_cast<cym19::BodySnapshot*>(p);}
void* cym19_impact_prepare(void*b,const double*lo,const double*hi,double strength){try{return new cym19::Impact(*static_cast<cym19::Body*>(b),lo,hi,strength);}catch(const std::exception&e){last_error=e.what();return nullptr;}}
void cym19_impact_destroy(void*p){delete static_cast<cym19::Impact*>(p);}
void* cym19_scene_create(void*b,int capacity){try{return new cym19::Scene(*static_cast<cym19::Body*>(b),capacity);}catch(const std::exception&e){last_error=e.what();return nullptr;}}
// Call only before processing; allocates and starts persistent workers.
int cym19_workers_prepare(void*s,int workers){try{auto&sc=*static_cast<cym19::Scene*>(s);if(sc.frame!=0)return 1;if(workers==1)sc.pool.reset();else sc.pool=std::make_unique<cym19::ParallelPool>(workers,std::max(sc.body.low.count,sc.body.high.count));return 0;}catch(const std::exception&e){last_error=e.what();return 1;}}
void cym19_scene_destroy(void*s){delete static_cast<cym19::Scene*>(s);}
int cym19_install(void*s,void*p){auto*sc=static_cast<cym19::Scene*>(s);audio_scope=true;uint64_t n=audio_allocations;int r=sc->install(static_cast<cym19::BodySnapshot*>(p));audio_scope=false;sc->allocs+=audio_allocations-n;return r;}
int cym19_strike(void*s,void*p){auto*sc=static_cast<cym19::Scene*>(s);audio_scope=true;uint64_t n=audio_allocations;int r=sc->strike(static_cast<cym19::Impact*>(p));audio_scope=false;sc->allocs+=audio_allocations-n;return r;}
int cym19_process(void*s,int n,double*out){return static_cast<cym19::Scene*>(s)->process(n,out);}
int cym19_reset(void*s){static_cast<cym19::Scene*>(s)->reset();return 0;}
uint64_t cym19_worker_allocations(void*s){auto&sc=*static_cast<cym19::Scene*>(s);return sc.pool?sc.pool->workerNews.load():0;}
int64_t cym19_frame(void*s){return static_cast<cym19::Scene*>(s)->frame;}
void cym19_stats(void*s,uint64_t*out){auto&v=*static_cast<cym19::Scene*>(s);out[0]=v.processCalls;out[1]=v.allocs;out[2]=v.rejectedStrikes;out[3]=v.active_count();out[4]=v.maxActive;}
// Exact-deadline timing without Python/ctypes call overhead; all buffers preallocated.
int cym19_run_blocks(void*s,int total,int block,double*out,double*timings,int*actualSizes){
 if(total<0||block<1||block>cym19::MaxBlock)return 1;
 int at=0,idx=0;while(at<total){int n=std::min(block,total-at);auto t=std::chrono::steady_clock::now();int rc=cym19_process(s,n,out+2*at);double dt=std::chrono::duration<double>(std::chrono::steady_clock::now()-t).count();if(rc)return rc;timings[idx]=dt;actualSizes[idx++]=n;at+=n;}return 0;
}
}
extern "C" int cym19_run_events(void*s,int total,int block,const int*eventFrames,const int*eventTypes,void*const*eventData,int eventCount,double*out,double*timings,int*actualSizes){
 if(total<0||block<1||block>cym19::MaxBlock||eventCount<0)return 1;
 for(int i=0;i<eventCount;i++)if(eventFrames[i]<0||eventFrames[i]>=total||(i&&eventFrames[i]<eventFrames[i-1]))return 1;
 int at=0,idx=0,ev=0;
 while(at<total){int end=std::min(at+block,total),n=end-at;auto t=std::chrono::steady_clock::now();
  while(at<end){
   while(ev<eventCount&&eventFrames[ev]==at){int rc=eventTypes[ev]==0?cym19_install(s,eventData[ev]):cym19_strike(s,eventData[ev]);if(rc)return rc;++ev;}
   int next=end;if(ev<eventCount)next=std::min(next,eventFrames[ev]);if(next<=at)return 1;
   int rc=cym19_process(s,next-at,out+2*at);if(rc)return rc;at=next;
  }
  timings[idx]=std::chrono::duration<double>(std::chrono::steady_clock::now()-t).count();actualSizes[idx++]=n;
 }
 return 0;
}

extern "C" int cym20_overlap_jobs(void*s,int enabled){auto&sc=*static_cast<cym19::Scene*>(s);if(sc.processing||sc.frame!=0)return 1;sc.overlapJobs=enabled!=0;return 0;}

extern "C" const char* cym20_backend_name(){
#ifdef CYM20_GLIBC_TRIG
#ifdef CYM20_TRIG8
 return "glibc-2.41-FMA-eight-lane";
#else
 return "glibc-2.41-FMA-four-lane";
#endif
#else
 return "platform-libm";
#endif
}

// Checkpoint21 additions are preparation/diagnostic APIs, never called concurrently
// with the audio callback. Default remains the measured old schedule until selected.
extern "C" int cym21_scheduler_prepare(void*s,int mode,int tile,int dg,int fg){
 try{return static_cast<cym19::Scene*>(s)->prepare_ranges(mode,tile,dg,fg);}catch(const std::exception&e){last_error=e.what();return 1;}
}
extern "C" int cym21_profile_enable(void*s,int enabled){auto&sc=*static_cast<cym19::Scene*>(s);if(sc.frame!=0||sc.processing)return 1;sc.rangeProfile=enabled!=0;return 0;}
extern "C" void cym21_scheduler_stats(void*s,double*out){
 auto&sc=*static_cast<cym19::Scene*>(s);out[0]=sc.rangePrep;out[1]=sc.rangeDispatch;out[2]=sc.rangeReduce;out[3]=sc.rangeBatches;
 for(int i=0;i<8;i++){out[4+i]=sc.rangeWorker[i].useful;out[12+i]=sc.rangeWorker[i].tasks;}
 out[20]=sc.rangeModal.size()*sizeof(double);
}

extern "C" int cym21_workers_prepare_hooks(void*s,int workers,void*context,int(*enter)(void*,int),void(*leave)(void*,int)){
 try{auto&sc=*static_cast<cym19::Scene*>(s);if(sc.processing||sc.frame!=0||workers<1||workers>8||(enter==nullptr)!=(leave==nullptr))return 1;
  if(workers==1)sc.pool.reset();else{auto team=std::make_unique<cym19::ParallelPool>(workers,std::max(sc.body.low.count,sc.body.high.count),context,enter,leave);sc.pool=std::move(team);}return 0;
 }catch(const std::exception&e){last_error=e.what();return 1;}
}
