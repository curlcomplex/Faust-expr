#pragma once
// Execution-only checkpoint-18 population. All constitutive expressions are
// extracted from the archived generated Faust class by prepare_coefficients().
// No oscillator, modulation sample, precision or summation-order reduction.
#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <memory>
#include <vector>
#include <stdexcept>
#include <chrono>
#ifdef CYM20_GLIBC_TRIG
#ifdef CYM20_TRIG8
#include "third_party/glibc-exact/trig_exact8.hpp"
namespace selected_trig=exacttrig8;
#else
#include "third_party/glibc-exact/trig_exact.hpp"
namespace selected_trig=exacttrig;
#endif
#endif

namespace cym19 {
constexpr int Rate=48000, Stride=21, Controls=23, MaxBlock=1024;
using D4=double __attribute__((vector_size(32)));
struct Coefficient { double hz,decay,audible,force,wscale,limit,sigma,atten,sn,co; };
struct Snapshot { std::vector<Coefficient> c; };
struct Model {
 int count,nk,knotstep,dynamicPrefix=0; std::vector<double> rows,knots;
 int partition[9][9]{};
 std::vector<int> kinds,starts; std::vector<double> activation;
 Model(const double* r,int n,const double* k,int nk0,int step):count(n),nk(nk0),knotstep(step),rows(r,r+size_t(n)*Stride),knots(k,k+size_t(n)*nk0),kinds(n),starts(n),activation(n){
  if(n<1||n>10000||nk<2||step<1)throw std::runtime_error("Invalid population dimensions");
  for(int i=0;i<n;i++){const auto*q=r+size_t(i)*Stride;for(int j=0;j<Stride;j++)if(!std::isfinite(q[j]))throw std::runtime_error("Nonfinite modal data");
   kinds[i]=int(q[20]);if(q[20]!=kinds[i]||kinds[i]<0||kinds[i]>2||q[0]<=0||q[1]<=0||q[19]<0||q[19]>10)throw std::runtime_error("Invalid modal row");
   if(kinds[i]==1)dynamicPrefix=std::min(n,((i+4)/4)*4);
   activation[i]=q[19]*Rate;starts[i]=int(std::ceil(activation[i]-1e-10));
  }
  // Scheduling weights only: no signal/data reduction. Each mode is still run.
  int groups=(count+3)/4,total=0;
  std::vector<int> weights(groups);
  for(int g=0;g<groups;g++){int cost=0;for(int k=g*4;k<std::min(count,g*4+4);k++)cost+=kinds[k]==1?8:1;weights[g]=cost;total+=cost;}
  for(int w=1;w<=8;w++){partition[w][0]=0;partition[w][w]=count;int g=0,cost=0;
   for(int i=1;i<w;i++){int target=total*i/w;while(g<groups&&cost<target){cost+=weights[g++];}partition[w][i]=std::min(count,g*4);}
  }
 }
};
struct alignas(32) GroupState { D4 lr{},li{},rr{},ri{}; double pending[4]{1,1,1,1},prephase[4]{}; };
// One strike cohort. Age-dependent drift/envelope is retained per impact, NOT
// restarted when another strike arrives. The enclosing stream applies the same
// body/contact snapshot to every cohort, including pending delayed excitation.
struct Population {
 const Model& model; const Snapshot* snapshot=nullptr; std::vector<GroupState> state;
 std::vector<double> forces; int64_t age=0; bool active=false;
 struct Scratch {
 alignas(32) double sinbuf[4][MaxBlock],cosbuf[4][MaxBlock],phasebuf[MaxBlock];
 alignas(32) double ex[4][4][MaxBlock];
 alignas(32) double out[4][2][MaxBlock];
 };
 Scratch scratch;
 double driftDecay[MaxBlock],fraction[MaxBlock];int knotlo[MaxBlock];
 explicit Population(const Model&m):model(m),state((m.count+3)/4),forces(size_t(m.count)*4){}
 void reset() noexcept { for(auto&g:state)g=GroupState{};age=0;active=false; }
 void strike(const double* excitation) noexcept { reset(); std::memcpy(forces.data(),excitation,forces.size()*sizeof(double));active=true; }
 void set_snapshot(const Snapshot*s) noexcept{snapshot=s;}
 // n=0 intentionally does not advance anything. Outputs are assigned, not added.
 double prep_s=0,loop_s=0,sum_s=0;
 int process(int n,double* audio) noexcept {
  if(n<0||n>MaxBlock||!audio||!snapshot)return 1;
  std::fill(audio,audio+2*n,0.);if(!active||n==0)return 0;
  const auto& m=model;
  for(int j=0;j<n;j++){
   double a=(age+j)/double(Rate);driftDecay[j]=std::exp(-a/1.8);
   double q=(age+j)/double(m.knotstep);int lo=std::clamp(int(std::floor(q)),0,m.nk-2);knotlo[j]=lo;fraction[j]=std::clamp(q-lo,0.,1.);
  }
  range(0,m.count,n,audio,nullptr,scratch);
  age+=n;
  for(int j=0;j<n*2;j++)if(!std::isfinite(audio[j]))return 2;
  return 0;
 }
 void range(int begin,int end,int n,double*audio,double*modal,Scratch&ws) noexcept {
  auto&sinbuf=ws.sinbuf;auto&cosbuf=ws.cosbuf;auto&ex=ws.ex;const auto&m=model;
  for(int base=begin;base<end;base+=4){
   const int lanes=std::min(4,m.count-base);auto& st=state[base/4];
   D4 dec{},aud{},force{},cs{},sn{};
   bool dynamic=false;int first=n;bool inject=false;
   for(int k=0;k<lanes;k++){
    dynamic |= m.kinds[base+k]==1;
    inject |= (m.starts[base+k]>=age&&m.starts[base+k]<age+n);
   }
   const bool simple=(!dynamic||lanes==4)&&!inject;
#ifdef CYM_PROFILE
   auto tprep=std::chrono::steady_clock::now();
#endif
   for(int k=0;k<lanes;k++){
    int idx=base+k;const double*r=m.rows.data()+size_t(idx)*Stride;const auto&c=snapshot->c[idx];const int kind=m.kinds[idx];const int start=m.starts[idx];
    dec[k]=c.decay;aud[k]=c.audible;force[k]=c.force;cs[k]=c.co;sn[k]=c.sn;dynamic|=kind==1;
    const int begin=std::clamp<int64_t>(start-age,0,n);first=std::min(first,begin);
    // Modal inputs are exactly zero except the original scheduled activation.
    if(!simple)for(int ch=0;ch<4;ch++)std::fill(ex[k][ch],ex[k][ch]+n,0.);
    if(kind!=1 && age>start){if(dynamic){std::fill(sinbuf[k],sinbuf[k]+n,c.sn);std::fill(cosbuf[k],cosbuf[k]+n,c.co);}continue;}
    if(kind==1 && age>start){
     const double* kn=m.knots.data()+size_t(idx)*m.nk;
     for(int j=0;j<n;j++){
      int lo=knotlo[j];double f=fraction[j];double drift=((1-f)*kn[lo]+f*kn[lo+1])*driftDecay[j];
      double w=c.wscale*std::min<double>(c.limit,std::max<double>(0.,c.hz*(drift+1.)));
#ifdef CYM20_GLIBC_TRIG
      ws.phasebuf[j]=w;
#else
      sinbuf[k][j]=std::sin(w);cosbuf[k][j]=std::cos(w);
#endif
     }
#ifdef CYM20_GLIBC_TRIG
     selected_trig::eval(n,ws.phasebuf,sinbuf[k],cosbuf[k]);
#endif
     continue;
    }

    for(int j=0;j<n;j++){
     int64_t s=age+j;double drift=0;
     if(kind==1){int lo=knotlo[j];double f=fraction[j];drift=((1-f)*m.knots[size_t(idx)*m.nk+lo]+f*m.knots[size_t(idx)*m.nk+lo+1])*driftDecay[j];
      // No trig needed while the state is provably zero. Phase accumulation for
      // the scheduled impulse is retained, sample by sample, below.
      if(s>=start){double w=c.wscale*std::min<double>(c.limit,std::max<double>(0.,c.hz*(drift+1.)));sinbuf[k][j]=std::sin(w);cosbuf[k][j]=std::cos(w);}
      else {sinbuf[k][j]=c.sn;cosbuf[k][j]=c.co;}
     }else{sinbuf[k][j]=c.sn;cosbuf[k][j]=c.co;}
     if(s<=start&&kind==1)st.prephase[k]+=2*M_PI*r[0]*(1+drift)/Rate;
     if(s<start)st.pending[k]*=c.atten;
     if(s==start){double phase=0,amp=st.pending[k];if(kind==1)phase=st.prephase[k];
      if(kind==2){double dt=(std::ceil(m.activation[idx]-1e-10)-m.activation[idx])/Rate;phase=2*M_PI*r[0]*dt;amp*=std::exp(-r[1]*dt);}
      double co=std::cos(phase),si=std::sin(phase);const double*v=forces.data()+size_t(idx)*4;
      ex[k][0][j]=amp*(v[0]*co-v[1]*si);ex[k][1][j]=amp*(v[0]*si+v[1]*co);
      ex[k][2][j]=amp*(v[2]*co-v[3]*si);ex[k][3][j]=amp*(v[2]*si+v[3]*co);
     }
    }
   }

#ifdef CYM_PROFILE
   auto tloop=std::chrono::steady_clock::now();prep_s+=std::chrono::duration<double>(tloop-tprep).count();
#endif
   D4 lr=st.lr,li=st.li,rr=st.rr,ri=st.ri;
   alignas(32) D4 yL[MaxBlock],yR[MaxBlock];
   // Constant-coefficient ringing is the dominant path outside activation blocks.

   if(!dynamic&&!inject){
    for(int j=0;j<n;j++){
     D4 nrL=dec*(cs*lr-sn*li)+D4{};
     D4 niL=dec*(lr*sn+cs*li)+D4{};
     D4 nrR=dec*(cs*rr-sn*ri)+D4{};
     D4 niR=dec*(sn*rr+cs*ri)+D4{};
     lr=nrL;li=niL;rr=nrR;ri=niR;yL[j]=lr;yR[j]=rr;
    }
   }else if(dynamic && !inject && lanes==4){
    for(int j=0;j<n;j++){
     cs=D4{cosbuf[0][j],cosbuf[1][j],cosbuf[2][j],cosbuf[3][j]};
     sn=D4{sinbuf[0][j],sinbuf[1][j],sinbuf[2][j],sinbuf[3][j]};
     D4 nrL=dec*(cs*lr-sn*li)+D4{};
     D4 niL=dec*(lr*sn+cs*li)+D4{};
     D4 nrR=dec*(cs*rr-sn*ri)+D4{};
     D4 niR=dec*(sn*rr+cs*ri)+D4{};
     lr=nrL;li=niL;rr=nrR;ri=niR;yL[j]=lr;yR[j]=rr;
    }
   }else{
    for(int j=0;j<n;j++){
     D4 erL{},eiL{},erR{},eiR{};
     for(int k=0;k<lanes;k++){if(dynamic){cs[k]=cosbuf[k][j];sn[k]=sinbuf[k][j];}erL[k]=ex[k][0][j];eiL[k]=ex[k][1][j];erR[k]=ex[k][2][j];eiR[k]=ex[k][3][j];}
     D4 nrL=dec*(cs*lr-sn*li)+erL*aud*force;
     D4 niL=dec*(lr*sn+cs*li)+eiL*aud*force;
     D4 nrR=dec*(cs*rr-sn*ri)+erR*aud*force;
     D4 niR=dec*(sn*rr+cs*ri)+eiR*aud*force;
     lr=nrL;li=niL;rr=nrR;ri=niR;yL[j]=lr;yR[j]=rr;
    }
   }
   st.lr=lr;st.li=li;st.rr=rr;st.ri=ri;
#ifdef CYM_PROFILE
   auto tsum=std::chrono::steady_clock::now();loop_s+=std::chrono::duration<double>(tsum-tloop).count();
#endif
   // Vectorise across TIME in the sum, never across modal order.
   if(modal){
    for(int k=0;k<lanes;k++)for(int j=0;j<n;j++){modal[2*(size_t(base+k)*n+j)]=yL[j][k];modal[2*(size_t(base+k)*n+j)+1]=yR[j][k];}
   }else{
    for(int k=0;k<lanes;k++)for(int j=0;j<n;j++){audio[2*j]+=yL[j][k];audio[2*j+1]+=yR[j][k];}
   }
#ifdef CYM_PROFILE
   sum_s+=std::chrono::duration<double>(std::chrono::steady_clock::now()-tsum).count();
#endif
  }
 }
 void pending(double* dst)const{for(int i=0;i<model.count;i++)dst[i]=state[i/4].pending[i%4];}
};
} // namespace cym19
