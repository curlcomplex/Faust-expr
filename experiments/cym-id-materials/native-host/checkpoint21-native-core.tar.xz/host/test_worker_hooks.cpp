#include "prepared_player.hpp"
#include <thread>
using namespace cymhost;
struct Hooks {std::atomic<int> entered{0},left{0},wrongThread{0};int fail=0;std::thread::id owner=std::this_thread::get_id();};
int enter(void*ctx,int index){auto&h=*static_cast<Hooks*>(ctx);if(std::this_thread::get_id()==h.owner)++h.wrongThread;if(index==h.fail)return 1234;++h.entered;return 0;}
void leave(void*ctx,int){auto&h=*static_cast<Hooks*>(ctx);if(std::this_thread::get_id()==h.owner)++h.wrongThread;++h.left;}
int main(int argc,char**argv){try{
 if(argc!=2)throw std::runtime_error("Provide prepared case");Prepared p(argv[1]);Hooks h;
 check(cym21_workers_prepare_hooks(p.scene,4,&h,enter,leave),"enter hooks");if(h.entered!=3)throw std::runtime_error("Missing worker starts");
 check(cym19_workers_prepare(p.scene,1),"stop worker hooks");if(h.left!=3||h.wrongThread!=0)throw std::runtime_error("Wrong leave lifecycle/thread");
 Hooks bad;bad.fail=2;int rc=cym21_workers_prepare_hooks(p.scene,4,&bad,enter,leave);
 if(rc==0||bad.entered!=bad.left||bad.wrongThread!=0)throw std::runtime_error("Setup failure not unwound");
 // The previous serial pool remains valid on failure. Scene model still renders.
 std::array<double,2048> out{};check(p.render(1024,out.data()),"post-failure rendering");
 std::cout<<"{\"success_starts\":"<<h.entered<<",\"success_leaves\":"<<h.left<<",\"failure_successful_starts\":"<<bad.entered<<",\"failure_leaves\":"<<bad.left<<",\"wrong_thread\":0,\"failure_rejected\":true,\"post_failure_render_ok\":true}\n";return 0;
}catch(const std::exception&e){std::cerr<<e.what()<<'\n';return 1;}}
