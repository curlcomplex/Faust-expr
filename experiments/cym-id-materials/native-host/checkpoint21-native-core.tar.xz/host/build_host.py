#!/usr/bin/env python3
"""Build the portable harness; on macOS also compile the Core Audio adapter.
The frozen DSP supports 48 kHz. No rate/precision/trig approximations are added.
"""
from pathlib import Path
import os,shlex,subprocess,sys,json
R=Path(__file__).resolve().parents[1]
cxx=shlex.split(os.environ.get('CXX','c++'))
flags=['-std=c++20','-O3','-ffp-contract=off','-pthread','-I',str(R/'native')]
if sys.platform=='darwin':flags+=['-mmacosx-version-min=12.0','-framework','AudioToolbox','-framework','CoreAudio']
(R/'build').mkdir(exist_ok=True)
cmd=cxx+flags+[str(R/'host/native_harness.cpp'),str(R/'native/scene.so'),'-o',str(R/'build/native_harness')]
subprocess.run(cmd,check=True)
(R/'evidence/host-build.json').write_text(json.dumps({'platform':sys.platform,'command':cmd,'core_audio_compiled':sys.platform=='darwin','device_test_executed':False},indent=2)+'\n')
print(R/'build/native_harness')
