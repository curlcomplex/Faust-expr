#!/usr/bin/env python3
"""Build, prepare and run a fixed test passage, offline or on Core Audio.
Core Audio is a source-only/unverified adapter in the delivered Linux-tested kit.
Not a VST, MIDI instrument, or variable-sample-rate engine.
"""
from pathlib import Path
import argparse,subprocess,sys,os,json,hashlib
R=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--mode',choices=['offline','device'],default='offline')
p.add_argument('--case',choices=['hard','roll3','passage'],default='passage')
p.add_argument('--workers',type=int,choices=range(1,9),default=4)
p.add_argument('--block',type=int,choices=[64,128,256,512,1024],default=128,help='Offline block size. Device mode uses actual device buffer size, never alters it.')
p.add_argument('--scheduler',type=int,choices=[0,1,2],default=2,help='0=old populations, 1=experimental full ranges, 2=hybrid')
p.add_argument('--no-build',action='store_true')
a=p.parse_args()
if a.mode=='device' and sys.platform!='darwin':p.error('Device mode requires macOS; no macOS result is claimed from Linux tests.')
if not a.no_build:subprocess.run([sys.executable,str(R/'run.py'),'--smoke','--full-tests','--workers',str(a.workers)],check=True,cwd=R)
subprocess.run([sys.executable,str(R/'host/build_host.py')],check=True,cwd=R)
case=R/f'build/host-{a.case}.bin'
subprocess.run([sys.executable,str(R/'tools/export_host_case.py'),'--case',a.case,'--out',str(case)],check=True,cwd=R)
out=R/f'evidence/host-{a.mode}-{a.case}-w{a.workers}'
print('Running',a.mode,'test. Device playback uses monitor attenuation 0.125. Raw capture is unattenuated.',flush=True)
subprocess.run([str(R/'build/native_harness'),str(case),str(out),a.mode,str(a.workers),str(a.block),str(a.scheduler)],check=True,cwd=R)
print('Report:',str(out)+'.json')

if a.mode=='device':
    # Compare the entire raw engine capture, before monitor attenuation, to an
    # offline replay built on this SAME Mac/libm. Cross-platform bit identity is
    # not assumed, and dropped samples are not hidden by alignment/normalisation.
    import numpy as np
    offline=R/f'evidence/host-device-reference-{a.case}-w{a.workers}'
    subprocess.run([str(R/'build/native_harness'),str(case),str(offline),'offline',str(a.workers),'128',str(a.scheduler)],check=True,cwd=R)
    x=np.fromfile(str(out)+'.f64',dtype='<f8');y=np.fromfile(str(offline)+'.f64',dtype='<f8')
    same=x.shape==y.shape and x.tobytes()==y.tobytes()
    result={'bit_exact':same,'max_abs':float(np.max(abs(x-y))) if x.shape==y.shape else None,'device_sha256':hashlib.sha256(x.tobytes()).hexdigest(),'offline_sha256':hashlib.sha256(y.tobytes()).hexdigest(),'same_machine_comparison':True}
    Path(str(out)+'-verification.json').write_text(json.dumps(result,indent=2)+'\n')
    if not same:raise RuntimeError('Device/offline audio mismatch; see saved raw captures and verification report.')
    print('Complete device/offline capture comparison: byte-identical.')
