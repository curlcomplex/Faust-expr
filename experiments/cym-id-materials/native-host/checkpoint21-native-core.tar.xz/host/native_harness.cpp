// Native exact-engine test host. Portable offline path tested on Linux.
// Core Audio path is SOURCE-ONLY here: it needs a macOS SDK build/device test.
#include "prepared_player.hpp"
#include <thread>
#include <cstring>
#include <cerrno>
#ifdef __APPLE__
#include <AudioToolbox/AudioToolbox.h>
#include <CoreAudio/CoreAudio.h>
#include <os/workgroup.h>
#include <mach/mach.h>
#include <mach/mach_time.h>
#include <mach/thread_policy.h>
#endif
using namespace cymhost;
#ifdef __APPLE__
struct Device {
 Recorder&r;AudioUnit au=nullptr;AudioDeviceID device=0;
 os_workgroup_t group=nullptr;os_workgroup_join_token_s tokens[8]{};bool joined[8]{};
 std::atomic<bool> armed{false};
 bool started=false;double nominalPeriod=0;int workers=1,scheduler=2;
 std::atomic<uint64_t> overloads{0};bool overloadListener=false;
 double previousTime=0;UInt32 previousFrames=0;bool validTime=false;
 alignas(64) double buffer[2048]{};
 explicit Device(Recorder&rr):r(rr){}
 static void oscheck(OSStatus e,const char*what){if(e!=noErr)throw std::runtime_error(std::string(what)+" OSStatus "+std::to_string(e));}
 static int enter(void*ctx,int i){
  auto&d=*static_cast<Device*>(ctx);mach_timebase_info_data_t tb{};mach_timebase_info(&tb);
  double ticks=d.nominalPeriod*1e9*double(tb.denom)/tb.numer;
  if(ticks<1||ticks>UINT32_MAX)return EINVAL;
  thread_time_constraint_policy_data_t policy{};
  policy.period=uint32_t(ticks);policy.computation=uint32_t(ticks*.5);policy.constraint=uint32_t(ticks);policy.preemptible=TRUE;
  mach_port_t thread=mach_thread_self();auto status=thread_policy_set(thread,THREAD_TIME_CONSTRAINT_POLICY,reinterpret_cast<thread_policy_t>(&policy),THREAD_TIME_CONSTRAINT_POLICY_COUNT);mach_port_deallocate(mach_task_self(),thread);
  if(status!=KERN_SUCCESS)return int(status);
  int rc=os_workgroup_join(d.group,&d.tokens[i]);if(!rc)d.joined[i]=true;return rc;
 }
 static void leave(void*ctx,int i){auto&d=*static_cast<Device*>(ctx);if(d.joined[i]){os_workgroup_leave(d.group,&d.tokens[i]);d.joined[i]=false;}}
 static OSStatus overload(AudioObjectID,UInt32,const AudioObjectPropertyAddress[],void*ctx){static_cast<Device*>(ctx)->overloads.fetch_add(1,std::memory_order_relaxed);return noErr;}
 static OSStatus callback(void*ctx,AudioUnitRenderActionFlags*flags,const AudioTimeStamp*ts,UInt32,UInt32 n,AudioBufferList*out)noexcept{
  auto&d=*static_cast<Device*>(ctx);
  auto silence=[&]{if(out)for(UInt32 i=0;i<out->mNumberBuffers;i++)if(out->mBuffers[i].mData)std::memset(out->mBuffers[i].mData,0,out->mBuffers[i].mDataByteSize);if(flags)*flags|=kAudioUnitRenderAction_OutputIsSilence;};
  if(!d.armed.load(std::memory_order_acquire)||d.r.finished.load(std::memory_order_acquire)){silence();return noErr;}
  auto callbackStart=std::chrono::steady_clock::now();
  if(n>1024||!out||out->mNumberBuffers!=1||out->mBuffers[0].mNumberChannels!=2||out->mBuffers[0].mDataByteSize<size_t(n)*2*sizeof(float)||!out->mBuffers[0].mData){silence();d.r.error.store(10);d.r.finished.store(true,std::memory_order_release);return kAudio_ParamError;}
  if(ts&&(ts->mFlags&kAudioTimeStampSampleTimeValid)){
   if(d.validTime&&std::abs(ts->mSampleTime-(d.previousTime+d.previousFrames))>.5)++d.r.sampleDiscontinuities;
   d.previousTime=ts->mSampleTime;d.previousFrames=n;d.validTime=true;
  }
  int rc=d.r.process(int(n),d.buffer);if(rc){silence();return kAudio_ParamError;}
  if(flags)*flags&=~kAudioUnitRenderAction_OutputIsSilence;
  float*dst=static_cast<float*>(out->mBuffers[0].mData);
  // Monitor-only safety attenuation and clipping. Exact pre-monitor float64
  // samples are captured for comparison; this does not enter the instrument.
  for(size_t j=0;j<size_t(n)*2;j++)dst[j]=float(std::clamp(d.buffer[j]*.125,-.98,.98));
  if(d.r.tickCount)d.r.ticks[d.r.tickCount-1].seconds=std::chrono::duration<double>(std::chrono::steady_clock::now()-callbackStart).count();
  return noErr;
 }
 void setup(int w,int mode){
  workers=w;scheduler=mode;
  AudioComponentDescription desc{};desc.componentType=kAudioUnitType_Output;desc.componentSubType=kAudioUnitSubType_DefaultOutput;desc.componentManufacturer=kAudioUnitManufacturer_Apple;
  auto component=AudioComponentFindNext(nullptr,&desc);if(!component)throw std::runtime_error("DefaultOutput component missing");
  oscheck(AudioComponentInstanceNew(component,&au),"Create output unit");
  UInt32 bytes=sizeof(device);oscheck(AudioUnitGetProperty(au,kAudioOutputUnitProperty_CurrentDevice,kAudioUnitScope_Global,0,&device,&bytes),"Output device");
  AudioObjectPropertyAddress rateAddress{kAudioDevicePropertyNominalSampleRate,kAudioObjectPropertyScopeGlobal,kAudioObjectPropertyElementMain};
  Float64 rate=0;bytes=sizeof(rate);oscheck(AudioObjectGetPropertyData(device,&rateAddress,0,nullptr,&bytes,&rate),"Device rate");
  if(rate!=48000)throw std::runtime_error("This frozen engine only supports 48000 Hz; default output device is not at that rate. No resampling or device-rate change was performed.");
  UInt32 hardwareFrames=0;AudioObjectPropertyAddress sizeAddress{kAudioDevicePropertyBufferFrameSize,kAudioObjectPropertyScopeGlobal,kAudioObjectPropertyElementMain};bytes=sizeof(hardwareFrames);
  oscheck(AudioObjectGetPropertyData(device,&sizeAddress,0,nullptr,&bytes,&hardwareFrames),"Device block size");if(!hardwareFrames||hardwareFrames>1024)throw std::runtime_error("Unsupported hardware block size");
  nominalPeriod=hardwareFrames/rate;
  AudioStreamBasicDescription format{};format.mSampleRate=48000;format.mFormatID=kAudioFormatLinearPCM;format.mFormatFlags=kAudioFormatFlagIsFloat|kAudioFormatFlagIsPacked|kAudioFormatFlagsNativeEndian;format.mBytesPerPacket=8;format.mFramesPerPacket=1;format.mBytesPerFrame=8;format.mChannelsPerFrame=2;format.mBitsPerChannel=32;
  oscheck(AudioUnitSetProperty(au,kAudioUnitProperty_StreamFormat,kAudioUnitScope_Input,0,&format,sizeof(format)),"Input format");
  UInt32 maxFrames=1024;oscheck(AudioUnitSetProperty(au,kAudioUnitProperty_MaximumFramesPerSlice,kAudioUnitScope_Global,0,&maxFrames,sizeof(maxFrames)),"Maximum slice");
  AURenderCallbackStruct cb{callback,this};oscheck(AudioUnitSetProperty(au,kAudioUnitProperty_SetRenderCallback,kAudioUnitScope_Input,0,&cb,sizeof(cb)),"Render callback");
  oscheck(AudioUnitInitialize(au),"Initialize");
  // Run the device silently before obtaining/joining its active workgroup.
  // Callback does not touch the scene until run() publishes armed=true.
  oscheck(AudioOutputUnitStart(au),"Start silent output");started=true;
  if(w>1){
   bytes=sizeof(group);oscheck(AudioUnitGetProperty(au,kAudioOutputUnitProperty_OSWorkgroup,kAudioUnitScope_Global,0,&group,&bytes),"Audio workgroup");
   if(!group)throw std::runtime_error("Output unit returned a null workgroup");
   // Keep an explicit owner until every auxiliary worker has left.
   os_retain(group);
   std::cerr<<"Audio workgroup recommended parallel threads: "<<os_workgroup_max_parallel_threads(group,nullptr)<<"\n";
   check(cym21_workers_prepare_hooks(r.p.scene,w,this,enter,leave),"Workgroup workers");
  }else check(cym19_workers_prepare(r.p.scene,1),"Serial worker");
  check(cym21_scheduler_prepare(r.p.scene,mode,128,64,256),"Scheduler");
  AudioObjectPropertyAddress overloadAddress{kAudioDeviceProcessorOverload,kAudioObjectPropertyScopeGlobal,kAudioObjectPropertyElementMain};
  overloadListener=AudioObjectAddPropertyListener(device,&overloadAddress,overload,this)==noErr;
  std::cerr<<"Device block "<<hardwareFrames<<" frames; monitor gain 0.125; exact engine capture before monitor gain.\n";
 }
 void run(){
  // Setup may succeed yet a disconnected/cancelled device may cease delivering
  // callbacks. Fail the test rather than waiting indefinitely. This watchdog
  // does not turn an over-budget run into a successful shortened render.
  const auto deadline=std::chrono::steady_clock::now()+std::chrono::duration<double>(std::max(15.0,4.0*double(r.p.total)/48000.0));
  armed.store(true,std::memory_order_release);
  bool timedOut=false;
  while(!r.finished.load(std::memory_order_acquire)){
   if(std::chrono::steady_clock::now()>deadline){timedOut=true;break;}
   std::this_thread::sleep_for(std::chrono::milliseconds(10));
  }
  armed.store(false,std::memory_order_release);
  oscheck(AudioOutputUnitStop(au),"Stop output");started=false;
  if(timedOut)throw std::runtime_error("Audio device test timed out before completing its prepared score; no real-time pass.");
 }
 ~Device(){
  if(started)AudioOutputUnitStop(au);
  if(overloadListener){AudioObjectPropertyAddress a{kAudioDeviceProcessorOverload,kAudioObjectPropertyScopeGlobal,kAudioObjectPropertyElementMain};AudioObjectRemovePropertyListener(device,&a,overload,this);}
  // Stop workers before releasing their tokens/workgroup/output unit.
  r.p.destroy_scene();if(group)os_release(group);
  if(au){AudioUnitUninitialize(au);AudioComponentInstanceDispose(au);}
 }
};
#endif
int main(int argc,char**argv){try{
 if(argc<4)throw std::runtime_error("usage: native_harness CASE.bin RESULT_PREFIX offline|device [workers=4] [block=128] [scheduler=2]");
 std::string mode=argv[3];int workers=argc>4?std::stoi(argv[4]):4,block=argc>5?std::stoi(argv[5]):128,scheduler=argc>6?std::stoi(argv[6]):2;
 if(workers<1||workers>8||block<8||block>1024||scheduler<0||scheduler>2)throw std::runtime_error("Invalid options");
 Prepared p(argv[1]);Recorder r(p);
 if(mode=="offline"){
  p.configure(workers,scheduler);std::array<double,2048> out{};
  // Warm all state paths and pages; deliberately excluded from timed callbacks.
  int warm=std::min(int(p.total),19200),done=0;while(done<warm){int n=std::min(block,warm-done);check(p.render(n,out.data()),"Warmup");done+=n;}p.reset();
  while(!r.finished.load(std::memory_order_relaxed)){int n=std::min(block,int(p.total)-p.at);check(r.process(n,out.data()),"Render");}
  r.write(argv[2],mode,workers,scheduler);
 }else if(mode=="device"){
#ifdef __APPLE__
  Device d(r);d.setup(workers,scheduler);d.run();r.write(argv[2],mode,workers,scheduler);
  std::ofstream extra(std::string(argv[2])+"-device.json");extra<<"{\"device_id\":"<<d.device<<",\"workgroup_workers\":"<<(d.group?workers-1:0)<<",\"overload_notifications\":"<<d.overloads.load()<<",\"overload_listener_registered\":"<<(d.overloadListener?"true":"false")<<",\"monitor_gain\":0.125,\"core_audio_test_executed\":true}\n";
  if(r.error.load())throw std::runtime_error("Device render failed; inspect error in report");
#else
  throw std::runtime_error("The Core Audio adapter requires a macOS build. It is not available or tested on this Linux host.");
#endif
 }else throw std::runtime_error("Mode must be offline or device");
 std::cout<<"Wrote "<<argv[2]<<".json and exact pre-monitor .f64 capture\n";return 0;
}catch(const std::exception&e){std::cerr<<e.what()<<'\n';return 1;}}
