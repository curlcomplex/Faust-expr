#pragma once
// Deterministic event playback shared by the portable test and Core Audio host.
// Does not implement or approximate the cymbal DSP. Everything calls scene_api.
#include "scene_api.h"
#include <algorithm>
#include <array>
#include <atomic>
#include <bit>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <limits>
#include <memory>
#include <stdexcept>
#include <string>
#include <vector>

namespace cymhost {
inline void check(int rc,const char*what){if(rc)throw std::runtime_error(std::string(what)+": "+interaction_error()+" ("+std::to_string(rc)+")");}
inline void pointer(void*p,const char*what){if(!p)throw std::runtime_error(std::string(what)+": "+interaction_error());}
struct Reader {
 std::ifstream f;size_t consumed=0,total=0;
 explicit Reader(const char*path):f(path,std::ios::binary){if(!f)throw std::runtime_error("Cannot open prepared case");f.seekg(0,std::ios::end);total=size_t(f.tellg());f.seekg(0);if(total>size_t(256)*1024*1024)throw std::runtime_error("Case exceeds bounded size");}
 void bytes(void*p,size_t n){if(n>total-consumed||!f.read(static_cast<char*>(p),std::streamsize(n)))throw std::runtime_error("Truncated case");consumed+=n;}
 uint32_t u32(){unsigned char p[4];bytes(p,4);return uint32_t(p[0])|(uint32_t(p[1])<<8)|(uint32_t(p[2])<<16)|(uint32_t(p[3])<<24);}
 std::vector<double> doubles(size_t n){static_assert(std::endian::native==std::endian::little);if(n>size_t(32)*1024*1024||n*8>total-consumed)throw std::runtime_error("Invalid array size");std::vector<double>x(n);bytes(x.data(),n*8);for(double v:x)if(!std::isfinite(v))throw std::runtime_error("Nonfinite case data");return x;}
};
struct Event {int frame,type,index;};
struct Prepared {
 void*body=nullptr;void*scene=nullptr;
 std::vector<void*> snapshots,impacts;std::vector<Event> events;
 uint32_t rate=48000,total=0,capacity=0;int at=0;size_t ev=0;
 explicit Prepared(const char*file){try{
  Reader r(file);char magic[8];r.bytes(magic,8);if(std::string(magic,8)!=std::string("CYM21PK\0",8))throw std::runtime_error("Wrong case magic");
  uint32_t h[12];for(auto&v:h)v=r.u32();
  auto version=h[0];rate=h[1];int nl=h[2],nh=h[3],nk=h[4],ks=h[5],ne=h[6],ns=h[7],ni=h[8],nev=h[9];total=h[10];capacity=h[11];
  if(version!=1||rate!=48000||nl<1||nl>10000||nh<1||nh>10000||nk<2||nk>100000||ks<1||ne<2||ne>10000||ns<1||ns>1024||ni<1||ni>64||nev<2||nev>4096||total<1||total>48000*120||capacity<1||capacity>64||unsigned(ni)>capacity)throw std::runtime_error("Invalid case dimensions");
  auto lo=r.doubles(size_t(nl)*21),hi=r.doubles(size_t(nh)*21),kn=r.doubles(size_t(nh)*nk),et=r.doubles(ne),ew=r.doubles(ne);
  body=cym19_body_create(lo.data(),nl,hi.data(),nh,kn.data(),nk,ks,et.data(),ew.data(),ne);pointer(body,"body");
  snapshots.reserve(ns);impacts.reserve(ni);events.reserve(nev);
  for(int i=0;i<ns;i++){auto ctr=r.doubles(23);void*p=cym19_snapshot_prepare(body,ctr.data());pointer(p,"snapshot");snapshots.push_back(p);}
  for(int i=0;i<ni;i++){auto strength=r.doubles(1),l=r.doubles(size_t(nl)*4),h0=r.doubles(size_t(nh)*4);void*p=cym19_impact_prepare(body,l.data(),h0.data(),strength[0]);pointer(p,"impact");impacts.push_back(p);}
  for(int i=0;i<nev;i++){auto fr=r.u32(),ty=r.u32(),ix=r.u32();if(fr>=total||ty>1||ix>=(ty==0?snapshots.size():impacts.size())||(i&&fr<unsigned(events.back().frame)))throw std::runtime_error("Invalid event");events.push_back({int(fr),int(ty),int(ix)});}
  if(events.front().frame!=0||events.front().type!=0||r.consumed!=r.total)throw std::runtime_error("Missing initial control / extra data");
  scene=cym19_scene_create(body,int(capacity));pointer(scene,"scene");
 }catch(...){cleanup();throw;}}
 void destroy_scene()noexcept{if(scene){cym19_scene_destroy(scene);scene=nullptr;}}
 void cleanup()noexcept{destroy_scene();for(auto*p:impacts)cym19_impact_destroy(p);impacts.clear();for(auto*p:snapshots)cym19_snapshot_destroy(p);snapshots.clear();if(body)cym19_body_destroy(body);body=nullptr;}
 ~Prepared(){cleanup();}
 Prepared(const Prepared&)=delete;Prepared&operator=(const Prepared&)=delete;
 void configure(int workers,int scheduler){check(cym19_workers_prepare(scene,workers),"workers");check(cym21_scheduler_prepare(scene,scheduler,128,64,256),"scheduler");}
 void reset(){check(cym19_reset(scene),"reset");at=0;ev=0;}
 // Output is exactly the requested next interval, with events applied at their
 // sample indices. Unfilled end-of-file frames are zero; no voice stealing.
 int render(int frames,double*out)noexcept{
  if(frames<0||frames>1024||!out||!scene)return 1;
  std::fill(out,out+size_t(frames)*2,0.);int done=0;
  while(done<frames&&unsigned(at)<total){
   while(ev<events.size()&&events[ev].frame==at){auto&e=events[ev];int rc=e.type==0?cym19_install(scene,snapshots[e.index]):cym19_strike(scene,impacts[e.index]);if(rc)return rc;++ev;}
   int n=std::min(frames-done,int(total)-at);if(ev<events.size())n=std::min(n,events[ev].frame-at);if(n<=0)return 1;
   int rc=cym19_process(scene,n,out+2*done);if(rc)return rc;at+=n;done+=n;
  }
  return 0;
 }
};
struct Tick {double seconds=0;uint32_t frames=0;};
struct Recorder {
 Prepared&p;std::vector<double> output;std::vector<Tick> ticks;
 std::atomic<bool> finished{false};std::atomic<int> error{0};
 size_t tickCount=0;uint64_t sampleDiscontinuities=0; // callback-owned until stopped
 explicit Recorder(Prepared&x):p(x),output(size_t(x.total)*2),ticks(size_t(x.total)/8+1024){}
 int process(int n,double*out)noexcept{
  auto start=std::chrono::steady_clock::now();int frame=p.at;
  int rc=p.render(n,out);int used=std::min(n,int(p.total)-frame);
  if(!rc&&used>0)std::copy(out,out+2*used,output.data()+2*frame);
  if(tickCount<ticks.size())ticks[tickCount++]={std::chrono::duration<double>(std::chrono::steady_clock::now()-start).count(),uint32_t(n)};
  else if(!rc)rc=5;
  if(rc){error.store(rc,std::memory_order_relaxed);finished.store(true,std::memory_order_release);return rc;}
  if(unsigned(p.at)>=p.total)finished.store(true,std::memory_order_release);return 0;
 }
 void write(const std::string&prefix,const std::string&mode,int workers,int scheduler){
  std::ofstream raw(prefix+".f64",std::ios::binary);raw.write(reinterpret_cast<const char*>(output.data()),std::streamsize(output.size()*8));if(!raw)throw std::runtime_error("Output write failed");
  std::ofstream csv(prefix+"-callbacks.csv");csv<<"frames,seconds\n";csv.precision(17);
  std::vector<double> times;uint64_t misses=0;double sum=0,peak=0;uint32_t minN=UINT32_MAX,maxN=0;
  for(size_t i=0;i<tickCount;i++){auto t=ticks[i];times.push_back(t.seconds);sum+=t.seconds;misses+=t.seconds>t.frames/double(p.rate);minN=std::min(minN,t.frames);maxN=std::max(maxN,t.frames);csv<<t.frames<<','<<t.seconds<<'\n';}
  for(double x:output)peak=std::max(peak,std::abs(x));std::sort(times.begin(),times.end());
  auto percentile=[&](double q){return times.empty()?0:times[size_t(q*(times.size()-1))]*1000;};
  uint64_t stats[5]{};if(p.scene)cym19_stats(p.scene,stats);
  std::ofstream report(prefix+".json");report.precision(17);
  report<<"{\"mode\":\""<<mode<<"\",\"rate\":"<<p.rate<<",\"frames\":"<<p.total<<",\"workers\":"<<workers<<",\"scheduler\":"<<scheduler<<",\"error\":"<<error.load()<<",\"callbacks\":"<<tickCount<<",\"block_min\":"<<minN<<",\"block_max\":"<<maxN<<",\"missed_compute_budgets\":"<<misses<<",\"dsp_and_capture_seconds\":"<<sum<<",\"callback_median_ms\":"<<percentile(.5)<<",\"callback_p99_ms\":"<<percentile(.99)<<",\"callback_max_ms\":"<<percentile(1)<<",\"peak\":"<<peak<<",\"sample_time_discontinuities\":"<<sampleDiscontinuities<<",\"scene_process_calls\":"<<stats[0]<<",\"caller_cpp_allocations\":"<<stats[1]<<",\"rejected_strikes\":"<<stats[2]<<",\"active_histories\":"<<stats[3]<<"}\n";
  if(!report||!csv)throw std::runtime_error("Report write failed");
 }
};
}
