/* ------------------------------------------------------------
name: "CYM-ID Thickness and Held Contact - experiment 02"
Code generated with Faust 2.70.3 (https://faust.grame.fr)
Compilation options: -lang cpp -ct 1 -cn InteractionPole -es 1 -mcd 16 -mdd 1024 -mdy 33 -double -ftz 0
------------------------------------------------------------ */

#ifndef  __InteractionPole_H__
#define  __InteractionPole_H__

#ifndef FAUSTFLOAT
#define FAUSTFLOAT float
#endif 

#include <algorithm>
#include <cmath>
#include <cstdint>
#include <math.h>

#ifndef FAUSTCLASS 
#define FAUSTCLASS InteractionPole
#endif

#ifdef __APPLE__ 
#define exp10f __exp10f
#define exp10 __exp10
#endif

#if defined(_WIN32)
#define RESTRICT __restrict
#else
#define RESTRICT __restrict__
#endif

static double InteractionPole_faustpower2_f(double value) {
	return value * value;
}
static double InteractionPole_faustpower4_f(double value) {
	return value * value * value * value;
}
static double InteractionPole_faustpower3_f(double value) {
	return value * value * value;
}

class InteractionPole : public dsp {
	
 private:
	
	FAUSTFLOAT fHslider0;
	FAUSTFLOAT fHslider1;
	FAUSTFLOAT fHslider2;
	FAUSTFLOAT fHslider3;
	FAUSTFLOAT fCheckbox0;
	FAUSTFLOAT fHslider4;
	FAUSTFLOAT fEntry0;
	FAUSTFLOAT fHslider5;
	FAUSTFLOAT fEntry1;
	FAUSTFLOAT fHslider6;
	FAUSTFLOAT fHslider7;
	FAUSTFLOAT fHslider8;
	FAUSTFLOAT fHslider9;
	FAUSTFLOAT fHslider10;
	FAUSTFLOAT fHslider11;
	FAUSTFLOAT fHslider12;
	FAUSTFLOAT fHslider13;
	FAUSTFLOAT fHslider14;
	FAUSTFLOAT fHslider15;
	FAUSTFLOAT fCheckbox1;
	FAUSTFLOAT fHslider16;
	FAUSTFLOAT fHslider17;
	FAUSTFLOAT fHslider18;
	FAUSTFLOAT fHslider19;
	FAUSTFLOAT fHslider20;
	FAUSTFLOAT fHslider21;
	FAUSTFLOAT fHslider22;
	FAUSTFLOAT fHslider23;
	FAUSTFLOAT fHslider24;
	FAUSTFLOAT fHslider25;
	FAUSTFLOAT fCheckbox2;
	FAUSTFLOAT fHslider26;
	FAUSTFLOAT fHslider27;
	FAUSTFLOAT fEntry2;
	FAUSTFLOAT fHslider28;
	FAUSTFLOAT fHslider29;
	int fSampleRate;
	double fConst1;
	double fConst2;
	double fConst3;
	double fConst4;
	FAUSTFLOAT fHslider30;
	FAUSTFLOAT fHslider31;
	FAUSTFLOAT fHslider32;
	FAUSTFLOAT fHslider33;
	FAUSTFLOAT fHslider34;
	FAUSTFLOAT fHslider35;
	double fConst5;
	FAUSTFLOAT fButton0;
	double fRec0[2];
	double fRec1[2];
	double fRec2[2];
	double fRec3[2];
	
 public:
	InteractionPole() {}

	void metadata(Meta* m) { 
		m->declare("basics.lib/name", "Faust Basic Element Library");
		m->declare("basics.lib/tabulateNd", "Copyright (C) 2023 Bart Brouns <bart@magnetophon.nl>");
		m->declare("basics.lib/version", "1.12.0");
		m->declare("compile_options", "-lang cpp -ct 1 -cn InteractionPole -es 1 -mcd 16 -mdd 1024 -mdy 33 -double -ftz 0");
		m->declare("description", "Named elastic/thermal properties with explicitly unmeasured loss factors. Not validated replacement-material cymbal physics.");
		m->declare("filename", "pole.dsp");
		m->declare("maths.lib/author", "GRAME");
		m->declare("maths.lib/copyright", "GRAME");
		m->declare("maths.lib/license", "LGPL with exception");
		m->declare("maths.lib/name", "Faust Math Library");
		m->declare("maths.lib/version", "2.7.0");
		m->declare("name", "CYM-ID Thickness and Held Contact - experiment 02");
		m->declare("platform.lib/name", "Generic Platform Library");
		m->declare("platform.lib/version", "1.3.0");
	}

	virtual int getNumInputs() {
		return 5;
	}
	virtual int getNumOutputs() {
		return 2;
	}
	
	static void classInit(int sample_rate) {
	}
	
	virtual void instanceConstants(int sample_rate) {
		fSampleRate = sample_rate;
		double fConst0 = std::min<double>(1.92e+05, std::max<double>(1.0, double(fSampleRate)));
		fConst1 = 0.48 * fConst0;
		fConst2 = 25.0 / fConst0;
		fConst3 = 5e+01 / fConst0;
		fConst4 = 6.283185307179586 / fConst0;
		fConst5 = 1.0 / fConst0;
	}
	
	virtual void instanceResetUserInterface() {
		fHslider0 = FAUSTFLOAT(1.0);
		fHslider1 = FAUSTFLOAT(1.0);
		fHslider2 = FAUSTFLOAT(1.0);
		fHslider3 = FAUSTFLOAT(0.0);
		fCheckbox0 = FAUSTFLOAT(0.0);
		fHslider4 = FAUSTFLOAT(0.0);
		fEntry0 = FAUSTFLOAT(0.0);
		fHslider5 = FAUSTFLOAT(0.0);
		fEntry1 = FAUSTFLOAT(1.0);
		fHslider6 = FAUSTFLOAT(1.2);
		fHslider7 = FAUSTFLOAT(0.0);
		fHslider8 = FAUSTFLOAT(1.0);
		fHslider9 = FAUSTFLOAT(1.0);
		fHslider10 = FAUSTFLOAT(1.0);
		fHslider11 = FAUSTFLOAT(1.0);
		fHslider12 = FAUSTFLOAT(998.0);
		fHslider13 = FAUSTFLOAT(0.0);
		fHslider14 = FAUSTFLOAT(1.0);
		fHslider15 = FAUSTFLOAT(0.0);
		fCheckbox1 = FAUSTFLOAT(0.0);
		fHslider16 = FAUSTFLOAT(0.0);
		fHslider17 = FAUSTFLOAT(0.0);
		fHslider18 = FAUSTFLOAT(0.0);
		fHslider19 = FAUSTFLOAT(0.0);
		fHslider20 = FAUSTFLOAT(0.0);
		fHslider21 = FAUSTFLOAT(1.0);
		fHslider22 = FAUSTFLOAT(1.0);
		fHslider23 = FAUSTFLOAT(2e+01);
		fHslider24 = FAUSTFLOAT(1.0);
		fHslider25 = FAUSTFLOAT(1.0);
		fCheckbox2 = FAUSTFLOAT(0.0);
		fHslider26 = FAUSTFLOAT(1.0);
		fHslider27 = FAUSTFLOAT(1e+03);
		fEntry2 = FAUSTFLOAT(0.0);
		fHslider28 = FAUSTFLOAT(5.0);
		fHslider29 = FAUSTFLOAT(8.0);
		fHslider30 = FAUSTFLOAT(0.001002);
		fHslider31 = FAUSTFLOAT(0.0);
		fHslider32 = FAUSTFLOAT(1.0);
		fHslider33 = FAUSTFLOAT(1.0);
		fHslider34 = FAUSTFLOAT(1.0);
		fHslider35 = FAUSTFLOAT(1.0);
		fButton0 = FAUSTFLOAT(0.0);
	}
	
	virtual void instanceClear() {
		for (int l0 = 0; l0 < 2; l0 = l0 + 1) {
			fRec0[l0] = 0.0;
		}
		for (int l1 = 0; l1 < 2; l1 = l1 + 1) {
			fRec1[l1] = 0.0;
		}
		for (int l2 = 0; l2 < 2; l2 = l2 + 1) {
			fRec2[l2] = 0.0;
		}
		for (int l3 = 0; l3 < 2; l3 = l3 + 1) {
			fRec3[l3] = 0.0;
		}
	}
	
	virtual void init(int sample_rate) {
		classInit(sample_rate);
		instanceInit(sample_rate);
	}
	
	virtual void instanceInit(int sample_rate) {
		instanceConstants(sample_rate);
		instanceResetUserInterface();
		instanceClear();
	}
	
	virtual InteractionPole* clone() {
		return new InteractionPole();
	}
	
	virtual int getSampleRate() {
		return fSampleRate;
	}
	
	virtual void buildUserInterface(UI* ui_interface) {
		ui_interface->openVerticalBox("CYM-ID Thickness and Held Contact - experiment 02");
		ui_interface->addHorizontalSlider("b0", &fHslider21, FAUSTFLOAT(1.0), FAUSTFLOAT(0.0), FAUSTFLOAT(1.0), FAUSTFLOAT(1e-08));
		ui_interface->addHorizontalSlider("b1", &fHslider20, FAUSTFLOAT(0.0), FAUSTFLOAT(0.0), FAUSTFLOAT(1.0), FAUSTFLOAT(1e-08));
		ui_interface->addHorizontalSlider("b2", &fHslider19, FAUSTFLOAT(0.0), FAUSTFLOAT(0.0), FAUSTFLOAT(1.0), FAUSTFLOAT(1e-08));
		ui_interface->addHorizontalSlider("b3", &fHslider18, FAUSTFLOAT(0.0), FAUSTFLOAT(0.0), FAUSTFLOAT(1.0), FAUSTFLOAT(1e-08));
		ui_interface->addHorizontalSlider("c0", &fHslider17, FAUSTFLOAT(0.0), FAUSTFLOAT(0.0), FAUSTFLOAT(1.0), FAUSTFLOAT(1e-08));
		ui_interface->addHorizontalSlider("c1", &fHslider16, FAUSTFLOAT(0.0), FAUSTFLOAT(0.0), FAUSTFLOAT(1.0), FAUSTFLOAT(1e-08));
		ui_interface->addButton("clear", &fButton0);
		ui_interface->declare(&fHslider29, "unit", "cm2");
		ui_interface->addHorizontalSlider("contact_area_cm2", &fHslider29, FAUSTFLOAT(8.0), FAUSTFLOAT(0.5), FAUSTFLOAT(6e+01), FAUSTFLOAT(0.01));
		ui_interface->declare(&fEntry2, "style", "menu{'Fingertip/palm-like':0;'Felt pad':1;'Fabric pad':2;'Leather pad':3;'Rubber pad':4;'Wood held block':5;'Bone-like held piece':6}");
		ui_interface->addNumEntry("contact_material", &fEntry2, FAUSTFLOAT(0.0), FAUSTFLOAT(0.0), FAUSTFLOAT(6.0), FAUSTFLOAT(1.0));
		ui_interface->declare(&fHslider28, "unit", "mm");
		ui_interface->addHorizontalSlider("contact_pad_mm", &fHslider28, FAUSTFLOAT(5.0), FAUSTFLOAT(0.2), FAUSTFLOAT(3e+01), FAUSTFLOAT(0.01));
		ui_interface->addHorizontalSlider("contact_pressure", &fHslider15, FAUSTFLOAT(0.0), FAUSTFLOAT(0.0), FAUSTFLOAT(1.0), FAUSTFLOAT(0.001));
		ui_interface->addHorizontalSlider("contact_strength", &fHslider14, FAUSTFLOAT(1.0), FAUSTFLOAT(0.0), FAUSTFLOAT(4.0), FAUSTFLOAT(0.001));
		ui_interface->addHorizontalSlider("d", &fHslider34, FAUSTFLOAT(1.0), FAUSTFLOAT(1e-06), FAUSTFLOAT(1e+04), FAUSTFLOAT(1e-06));
		ui_interface->addHorizontalSlider("diameter_ratio", &fHslider2, FAUSTFLOAT(1.0), FAUSTFLOAT(0.4), FAUSTFLOAT(2.5), FAUSTFLOAT(0.0001));
		ui_interface->addCheckButton("external_excitation", &fCheckbox0);
		ui_interface->addHorizontalSlider("f", &fHslider27, FAUSTFLOAT(1e+03), FAUSTFLOAT(1.0), FAUSTFLOAT(1e+05), FAUSTFLOAT(1e-06));
		ui_interface->addHorizontalSlider("fluid_density", &fHslider12, FAUSTFLOAT(998.0), FAUSTFLOAT(0.1), FAUSTFLOAT(2e+04), FAUSTFLOAT(0.01));
		ui_interface->addHorizontalSlider("fluid_viscosity", &fHslider30, FAUSTFLOAT(0.001002), FAUSTFLOAT(1e-07), FAUSTFLOAT(2.0), FAUSTFLOAT(1e-06));
		ui_interface->declare(&fHslider26, "scale", "log");
		ui_interface->addHorizontalSlider("frequency_scale", &fHslider26, FAUSTFLOAT(1.0), FAUSTFLOAT(0.125), FAUSTFLOAT(8.0), FAUSTFLOAT(0.001));
		ui_interface->addHorizontalSlider("geometry_compensation", &fHslider22, FAUSTFLOAT(1.0), FAUSTFLOAT(0.01), FAUSTFLOAT(1e+02), FAUSTFLOAT(1e-06));
		ui_interface->addCheckButton("geometry_pitch_compensate", &fCheckbox1);
		ui_interface->addHorizontalSlider("grip", &fHslider31, FAUSTFLOAT(0.0), FAUSTFLOAT(0.0), FAUSTFLOAT(1.0), FAUSTFLOAT(0.001));
		ui_interface->addHorizontalSlider("grip_strength", &fHslider32, FAUSTFLOAT(1.0), FAUSTFLOAT(0.1), FAUSTFLOAT(4.0), FAUSTFLOAT(0.001));
		ui_interface->addHorizontalSlider("hydro", &fHslider13, FAUSTFLOAT(0.0), FAUSTFLOAT(0.0), FAUSTFLOAT(2.0), FAUSTFLOAT(1e-08));
		ui_interface->addHorizontalSlider("immersion", &fHslider4, FAUSTFLOAT(0.0), FAUSTFLOAT(0.0), FAUSTFLOAT(1.0), FAUSTFLOAT(1e-05));
		ui_interface->declare(&fHslider33, "scale", "log");
		ui_interface->addHorizontalSlider("intrinsic_loss_scale", &fHslider33, FAUSTFLOAT(1.0), FAUSTFLOAT(0.1), FAUSTFLOAT(1e+01), FAUSTFLOAT(0.001));
		ui_interface->declare(&fHslider35, "scale", "log");
		ui_interface->addHorizontalSlider("loss_scale", &fHslider35, FAUSTFLOAT(1.0), FAUSTFLOAT(0.25), FAUSTFLOAT(8.0), FAUSTFLOAT(0.001));
		ui_interface->addHorizontalSlider("mass_edge", &fHslider3, FAUSTFLOAT(0.0), FAUSTFLOAT(0.0), FAUSTFLOAT(1.0), FAUSTFLOAT(1e-08));
		ui_interface->declare(&fEntry0, "style", "menu{'Original / bronze reference':0;'Gold (pure)':1;'Silver (pure)':2;'Titanium':3;'Steel (carbon)':4;'Aluminium':5;'Copper (C11000)':6;'Brass (C26000)':7;'Glass (fused silica)':8;'Glass (borosilicate)':9;'Acrylic (PMMA)':10;'Wood (effective)':11}");
		ui_interface->addNumEntry("material_a", &fEntry0, FAUSTFLOAT(0.0), FAUSTFLOAT(0.0), FAUSTFLOAT(11.0), FAUSTFLOAT(1.0));
		ui_interface->declare(&fEntry1, "style", "menu{'Original / bronze reference':0;'Gold (pure)':1;'Silver (pure)':2;'Titanium':3;'Steel (carbon)':4;'Aluminium':5;'Copper (C11000)':6;'Brass (C26000)':7;'Glass (fused silica)':8;'Glass (borosilicate)':9;'Acrylic (PMMA)':10;'Wood (effective)':11}");
		ui_interface->addNumEntry("material_b", &fEntry1, FAUSTFLOAT(1.0), FAUSTFLOAT(0.0), FAUSTFLOAT(11.0), FAUSTFLOAT(1.0));
		ui_interface->addHorizontalSlider("material_depth", &fHslider25, FAUSTFLOAT(1.0), FAUSTFLOAT(0.0), FAUSTFLOAT(1.0), FAUSTFLOAT(0.001));
		ui_interface->addHorizontalSlider("material_mix", &fHslider5, FAUSTFLOAT(0.0), FAUSTFLOAT(0.0), FAUSTFLOAT(1.0), FAUSTFLOAT(0.001));
		ui_interface->addCheckButton("pitch_lock", &fCheckbox2);
		ui_interface->declare(&fHslider1, "scale", "log");
		ui_interface->addHorizontalSlider("rim_thickness_ratio", &fHslider1, FAUSTFLOAT(1.0), FAUSTFLOAT(0.25), FAUSTFLOAT(4.0), FAUSTFLOAT(0.001));
		ui_interface->addHorizontalSlider("temperature_C", &fHslider23, FAUSTFLOAT(2e+01), FAUSTFLOAT(-1.5e+02), FAUSTFLOAT(1e+02), FAUSTFLOAT(0.1));
		ui_interface->addHorizontalSlider("thermal_modulus_ratio", &fHslider24, FAUSTFLOAT(1.0), FAUSTFLOAT(0.02), FAUSTFLOAT(2.0), FAUSTFLOAT(1e-06));
		ui_interface->declare(&fHslider6, "unit", "mm");
		ui_interface->addHorizontalSlider("thermal_thickness_mm", &fHslider6, FAUSTFLOAT(1.2), FAUSTFLOAT(0.2), FAUSTFLOAT(6.0), FAUSTFLOAT(0.01));
		ui_interface->declare(&fHslider0, "scale", "log");
		ui_interface->addHorizontalSlider("thickness_ratio", &fHslider0, FAUSTFLOAT(1.0), FAUSTFLOAT(0.125), FAUSTFLOAT(8.0), FAUSTFLOAT(0.001));
		ui_interface->addHorizontalSlider("wet0", &fHslider7, FAUSTFLOAT(0.0), FAUSTFLOAT(0.0), FAUSTFLOAT(2.0), FAUSTFLOAT(1e-08));
		ui_interface->addHorizontalSlider("wet1", &fHslider11, FAUSTFLOAT(1.0), FAUSTFLOAT(0.0), FAUSTFLOAT(2.0), FAUSTFLOAT(1e-08));
		ui_interface->addHorizontalSlider("wet2", &fHslider10, FAUSTFLOAT(1.0), FAUSTFLOAT(0.0), FAUSTFLOAT(2.0), FAUSTFLOAT(1e-08));
		ui_interface->addHorizontalSlider("wet3", &fHslider9, FAUSTFLOAT(1.0), FAUSTFLOAT(0.0), FAUSTFLOAT(2.0), FAUSTFLOAT(1e-08));
		ui_interface->addHorizontalSlider("wet4", &fHslider8, FAUSTFLOAT(1.0), FAUSTFLOAT(0.0), FAUSTFLOAT(2.0), FAUSTFLOAT(1e-08));
		ui_interface->closeBox();
	}
	

private:
	double fSlow0 = 0;
	double fSlow1 = 0;
	double fSlow2 = 0;
	int iSlow3 = 0;
	int iSlow4 = 0;
	double fSlow5 = 0;
	double fSlow6 = 0;
	double fSlow7 = 0;
	double fSlow8 = 0;
	double fSlow9 = 0;
	int iSlow10 = 0;
	int iSlow11 = 0;
	int iSlow12 = 0;
	int iSlow13 = 0;
	int iSlow14 = 0;
	int iSlow15 = 0;
	int iSlow16 = 0;
	int iSlow17 = 0;
	int iSlow18 = 0;
	int iSlow19 = 0;
	int iSlow20 = 0;
	int iSlow21 = 0;
	int iSlow22 = 0;
	double fSlow23 = 0;
	double fSlow24 = 0;
	int iSlow25 = 0;
	int iSlow26 = 0;
	int iSlow27 = 0;
	int iSlow28 = 0;
	int iSlow29 = 0;
	int iSlow30 = 0;
	int iSlow31 = 0;
	int iSlow32 = 0;
	int iSlow33 = 0;
	int iSlow34 = 0;
	int iSlow35 = 0;
	int iSlow36 = 0;
	double fSlow37 = 0;
	double fSlow38 = 0;
	double fSlow39 = 0;
	double fSlow40 = 0;
	double fSlow41 = 0;
	double fSlow42 = 0;
	double fSlow43 = 0;
	double fSlow44 = 0;
	int iSlow45 = 0;
	double fSlow46 = 0;
	double fSlow47 = 0;
	double fSlow48 = 0;
	double fSlow49 = 0;
	double fSlow50 = 0;
	double fSlow51 = 0;
	double fSlow52 = 0;
	double fSlow53 = 0;
	double fSlow54 = 0;
	double fSlow55 = 0;
	double fSlow56 = 0;
	int iSlow57 = 0;
	int iSlow58 = 0;
	double fSlow59 = 0;
	int iSlow60 = 0;
	double fSlow61 = 0;
	double fSlow62 = 0;
	double fSlow63 = 0;
	double fSlow64 = 0;
	double fSlow65 = 0;
	double fSlow66 = 0;
	double fSlow67 = 0;
	double fSlow68 = 0;
	int iSlow69 = 0;
	int iSlow70 = 0;
	int iSlow71 = 0;
	int iSlow72 = 0;
	int iSlow73 = 0;
	int iSlow74 = 0;
	int iSlow75 = 0;
	double fSlow76 = 0;
	double fSlow77 = 0;
	double fSlow78 = 0;
	double fSlow79 = 0;
	double fSlow80 = 0;
	double fSlow81 = 0;
	double fSlow82 = 0;
	double fSlow83 = 0;
	double fSlow84 = 0;
	double fSlow85 = 0;
	double fSlow86 = 0;
	double fSlow87 = 0;
	double fSlow88 = 0;
	double fSlow89 = 0;
	double fSlow90 = 0;
	double fSlow91 = 0;
	double fSlow92 = 0;
	double fSlow93 = 0;
	double fSlow94 = 0;
	double fSlow95 = 0;
	double fSlow96 = 0;
	double fSlow97 = 0;
	double fSlow98 = 0;
	int iSlow99 = 0;
	double fSlow100 = 0;
	double fSlow101 = 0;
	double fSlow102 = 0;
	double fSlow103 = 0;
	double fSlow104 = 0;
	double fSlow105 = 0;
	double fSlow106 = 0;
	double fSlow107 = 0;
	double fSlow108 = 0;
	double fSlow109 = 0;
	double fSlow110 = 0;
	double fSlow111 = 0;
	double fSlow112 = 0;
	double fSlow113 = 0;
	double fSlow114 = 0;
	double fSlow115 = 0;
public:

	void refreshCoefficients() {
		fSlow0 = double(fHslider0);
		fSlow1 = double(fHslider1);
		fSlow2 = double(fHslider2);
		iSlow3 = fSlow2 == 1.0;
		iSlow4 = iSlow3 * (fSlow1 == 1.0) * (fSlow0 == 1.0);
		fSlow5 = double(fHslider3) * (fSlow1 + -1.0) + 1.0;
		fSlow6 = InteractionPole_faustpower2_f(fSlow2);
		fSlow7 = fSlow0 * fSlow6 * fSlow5;
		fSlow8 = ((iSlow4) ? 1.0 : 1.0 / std::max<double>(0.001, fSlow7));
		fSlow9 = double(fHslider4);
		iSlow10 = fSlow9 == 0.0;
		iSlow11 = int(double(fEntry0));
		iSlow12 = iSlow11 >= 6;
		iSlow13 = iSlow11 >= 3;
		iSlow14 = iSlow11 >= 2;
		iSlow15 = iSlow11 >= 1;
		iSlow16 = iSlow11 >= 5;
		iSlow17 = iSlow11 >= 4;
		iSlow18 = iSlow11 >= 9;
		iSlow19 = iSlow11 >= 8;
		iSlow20 = iSlow11 >= 7;
		iSlow21 = iSlow11 >= 11;
		iSlow22 = iSlow11 >= 10;
		fSlow23 = double(fHslider5);
		fSlow24 = 1.0 - fSlow23;
		iSlow25 = int(double(fEntry1));
		iSlow26 = iSlow25 >= 6;
		iSlow27 = iSlow25 >= 3;
		iSlow28 = iSlow25 >= 2;
		iSlow29 = iSlow25 >= 1;
		iSlow30 = iSlow25 >= 5;
		iSlow31 = iSlow25 >= 4;
		iSlow32 = iSlow25 >= 9;
		iSlow33 = iSlow25 >= 8;
		iSlow34 = iSlow25 >= 7;
		iSlow35 = iSlow25 >= 11;
		iSlow36 = iSlow25 >= 10;
		fSlow37 = std::exp(fSlow23 * std::log(0.00011363636363636364 * ((iSlow26) ? ((iSlow32) ? ((iSlow35) ? 7e+02 : ((iSlow36) ? 1.19e+03 : 2.23e+03)) : ((iSlow33) ? 2.2e+03 : ((iSlow34) ? 8.53e+03 : 8.91e+03))) : ((iSlow27) ? ((iSlow30) ? 2.7e+03 : ((iSlow31) ? 7.85e+03 : 4.51e+03)) : ((iSlow28) ? 1.049e+04 : ((iSlow29) ? 19325.0 : 8.8e+03))))) + fSlow24 * std::log(0.00011363636363636364 * ((iSlow12) ? ((iSlow18) ? ((iSlow21) ? 7e+02 : ((iSlow22) ? 1.19e+03 : 2.23e+03)) : ((iSlow19) ? 2.2e+03 : ((iSlow20) ? 8.53e+03 : 8.91e+03))) : ((iSlow13) ? ((iSlow16) ? 2.7e+03 : ((iSlow17) ? 7.85e+03 : 4.51e+03)) : ((iSlow14) ? 1.049e+04 : ((iSlow15) ? 19325.0 : 8.8e+03))))));
		fSlow38 = double(fHslider6);
		fSlow39 = std::max<double>(1e-12, 8.8 * fSlow0 * fSlow38 * fSlow5 * fSlow37);
		fSlow40 = 1.0 - fSlow9;
		fSlow41 = std::max<double>(0.0, std::min<double>(1.0, fSlow9 * (4.0 * double(fHslider11) * InteractionPole_faustpower3_f(fSlow40) + 6.0 * double(fHslider10) * fSlow9 * InteractionPole_faustpower2_f(fSlow40) + 4.0 * double(fHslider9) * InteractionPole_faustpower2_f(fSlow9) * fSlow40) + double(fHslider8) * InteractionPole_faustpower4_f(fSlow9) + double(fHslider7) * InteractionPole_faustpower4_f(fSlow40)));
		fSlow42 = double(fHslider12);
		fSlow43 = double(fHslider14);
		fSlow44 = double(fHslider15);
		iSlow45 = (fSlow44 < 1e-12) + (fSlow43 == 0.0);
		fSlow46 = double(fHslider16) * fSlow1;
		fSlow47 = double(fHslider17);
		fSlow48 = InteractionPole_faustpower2_f(fSlow0);
		fSlow49 = fSlow48 * (double(fHslider21) + fSlow1 * (double(fHslider20) + fSlow1 * (double(fHslider19) + double(fHslider18) * fSlow1)));
		fSlow50 = ((iSlow4) ? 1.0 : ((iSlow3) ? std::sqrt(std::max<double>(1e-12, (fSlow46 + fSlow47 + fSlow49) / fSlow5)) : std::sqrt(std::max<double>(1e-12, (fSlow49 / InteractionPole_faustpower4_f(fSlow2) + (fSlow47 + fSlow46) / fSlow6) / fSlow5))));
		fSlow51 = ((iSlow12) ? ((iSlow18) ? ((iSlow21) ? 5e-06 : ((iSlow22) ? 8e-05 : 3.25e-06)) : ((iSlow19) ? 5.7e-07 : ((iSlow20) ? 1.9980000000000002e-05 : 1.692e-05))) : ((iSlow13) ? ((iSlow16) ? 2.3e-05 : ((iSlow17) ? 1.2e-05 : 8.41e-06)) : ((iSlow14) ? 1.89e-05 : ((iSlow15) ? 1.4e-05 : 1.7e-05))));
		fSlow52 = fSlow51 + fSlow23 * (((iSlow26) ? ((iSlow32) ? ((iSlow35) ? 5e-06 : ((iSlow36) ? 8e-05 : 3.25e-06)) : ((iSlow33) ? 5.7e-07 : ((iSlow34) ? 1.9980000000000002e-05 : 1.692e-05))) : ((iSlow27) ? ((iSlow30) ? 2.3e-05 : ((iSlow31) ? 1.2e-05 : 8.41e-06)) : ((iSlow28) ? 1.89e-05 : ((iSlow29) ? 1.4e-05 : 1.7e-05)))) - fSlow51);
		fSlow53 = double(fHslider23);
		fSlow54 = std::max<double>(0.1, (fSlow53 + -2e+01) * fSlow52 + 1.0);
		fSlow55 = double(fHslider24);
		fSlow56 = std::sqrt(fSlow55 * fSlow54);
		iSlow57 = iSlow11 == 0;
		iSlow58 = (iSlow57 * (fSlow23 == 0.0) + (iSlow25 == 0) * (iSlow57 + (fSlow23 == 1.0))) > 0;
		fSlow59 = double(fHslider25);
		iSlow60 = fSlow59 == 0.0;
		fSlow61 = ((iSlow12) ? ((iSlow18) ? ((iSlow21) ? 0.3 : ((iSlow22) ? 0.35 : 0.2)) : ((iSlow19) ? 0.17 : ((iSlow20) ? 0.33333333333333326 : 0.328125))) : ((iSlow13) ? ((iSlow16) ? 0.33 : ((iSlow17) ? 0.3 : 0.361)) : ((iSlow14) ? 0.37 : ((iSlow15) ? 0.44 : 0.34))));
		fSlow62 = std::exp(fSlow23 * std::log(9.09090909090909e-12 * ((iSlow26) ? ((iSlow32) ? ((iSlow35) ? 3.2e+09 : ((iSlow36) ? 3.3e+09 : 6.4e+10)) : ((iSlow33) ? 7.17e+10 : ((iSlow34) ? 110316116688.0 : 117210873981.0))) : ((iSlow27) ? ((iSlow30) ? 6.91e+10 : ((iSlow31) ? 2.058e+11 : 1.2e+11)) : ((iSlow28) ? 8.3e+10 : ((iSlow29) ? 7.8e+10 : 1.1e+11))))) + fSlow24 * std::log(9.09090909090909e-12 * ((iSlow12) ? ((iSlow18) ? ((iSlow21) ? 3.2e+09 : ((iSlow22) ? 3.3e+09 : 6.4e+10)) : ((iSlow19) ? 7.17e+10 : ((iSlow20) ? 110316116688.0 : 117210873981.0))) : ((iSlow13) ? ((iSlow16) ? 6.91e+10 : ((iSlow17) ? 2.058e+11 : 1.2e+11)) : ((iSlow14) ? 8.3e+10 : ((iSlow15) ? 7.8e+10 : 1.1e+11))))));
		fSlow63 = std::exp(fSlow59 * std::log(std::sqrt(0.8844 * (fSlow62 / (fSlow37 * (1.0 - InteractionPole_faustpower2_f(fSlow61 + fSlow23 * (((iSlow26) ? ((iSlow32) ? ((iSlow35) ? 0.3 : ((iSlow36) ? 0.35 : 0.2)) : ((iSlow33) ? 0.17 : ((iSlow34) ? 0.33333333333333326 : 0.328125))) : ((iSlow27) ? ((iSlow30) ? 0.33 : ((iSlow31) ? 0.3 : 0.361)) : ((iSlow28) ? 0.37 : ((iSlow29) ? 0.44 : 0.34)))) - fSlow61))))))));
		fSlow64 = (((double(fCheckbox2) + double(iSlow60) + double(iSlow58)) > 0.0) ? 1.0 : fSlow63) * fSlow56;
		fSlow65 = double(fHslider27);
		fSlow66 = fSlow65 * double(fHslider26);
		fSlow67 = ((iSlow4) ? fSlow66 * fSlow64 : fSlow66 * fSlow64 * ((int(double(fCheckbox1))) ? double(fHslider22) * fSlow50 : fSlow50));
		fSlow68 = InteractionPole_faustpower2_f(fSlow67);
		iSlow69 = int(double(fEntry2));
		iSlow70 = iSlow69 >= 4;
		iSlow71 = iSlow69 >= 2;
		iSlow72 = iSlow69 >= 1;
		iSlow73 = iSlow69 >= 3;
		iSlow74 = iSlow69 >= 6;
		iSlow75 = iSlow69 >= 5;
		fSlow76 = ((iSlow70) ? ((iSlow74) ? 3e-05 : ((iSlow75) ? 3e-05 : 4e-05)) : ((iSlow71) ? ((iSlow73) ? 3e-05 : 0.00015) : ((iSlow72) ? 8e-05 : 0.0002)));
		fSlow77 = InteractionPole_faustpower2_f(fSlow76);
		fSlow78 = 39.47841760435743 * fSlow77 * fSlow68 + 1.0;
		fSlow79 = ((iSlow70) ? ((iSlow74) ? 4e+08 : ((iSlow75) ? 3e+08 : 3e+06)) : ((iSlow71) ? ((iSlow73) ? 2e+06 : 6e+04) : ((iSlow72) ? 1.5e+05 : 3e+05)));
		fSlow80 = ((iSlow70) ? 0.001 : ((iSlow71) ? ((iSlow73) ? 0.001 : 0.004) : ((iSlow72) ? 0.002 : 0.006)));
		fSlow81 = InteractionPole_faustpower2_f(fSlow80);
		fSlow82 = 39.47841760435743 * fSlow68 * fSlow81 + 1.0;
		fSlow83 = ((iSlow70) ? ((iSlow74) ? 1.5e+08 : ((iSlow75) ? 1e+08 : 2e+06)) : ((iSlow71) ? ((iSlow73) ? 1e+06 : 2.5e+04) : ((iSlow72) ? 6e+04 : 2e+05)));
		fSlow84 = fSlow83 * fSlow80 / fSlow82 + fSlow76 * fSlow79 / fSlow78;
		fSlow85 = double(fHslider29) / double(fHslider28);
		fSlow86 = 0.6283185307179586 * fSlow85 * fSlow84 + 75.39822368615503;
		fSlow87 = ((iSlow70) ? ((iSlow74) ? 1.5e+10 : ((iSlow75) ? 1e+10 : 1.5e+06)) : ((iSlow71) ? ((iSlow73) ? 3e+06 : 5e+03) : ((iSlow72) ? 3e+04 : 8e+04))) + 39.47841760435743 * fSlow68 * (fSlow83 * fSlow81 / fSlow82 + fSlow77 * fSlow79 / fSlow78);
		fSlow88 = 0.1 * fSlow85 * fSlow87 + 1e+05;
		fSlow89 = InteractionPole_faustpower2_f(fSlow88) + fSlow68 * InteractionPole_faustpower2_f(fSlow86);
		fSlow90 = 7.5398223686155035 * fSlow87 + 62831.853071795864 * fSlow84;
		fSlow91 = 1e+04 * fSlow87 - 47.37410112522892 * fSlow68 * fSlow84;
		fSlow92 = fSlow43 * InteractionPole_faustpower2_f(fSlow44) / fSlow7;
		fSlow93 = std::max<double>(1.0, fSlow67);
		fSlow94 = ((iSlow45) ? fSlow67 : 0.15915494309189535 * std::sqrt(39.47841760435743 * InteractionPole_faustpower2_f(fSlow93) + 8.0 * fSlow92 * std::max<double>(0.0, fSlow85 * ((fSlow91 * fSlow88 + fSlow68 * fSlow90 * fSlow86) / fSlow89))));
		fSlow95 = ((iSlow10) ? fSlow94 : fSlow94 / std::sqrt(std::max<double>(0.0, 0.25 * double(fHslider13) * fSlow2 * fSlow42 * fSlow41 / fSlow39) + 1.0));
		fSlow96 = fConst1 - fSlow95;
		fSlow97 = ((int(double(fCheckbox0))) ? std::min<double>(1.0, std::max<double>(0.0, fConst3 * fSlow96)) : std::min<double>(1.0, std::max<double>(0.0, fConst2 * fSlow96)));
		fSlow98 = double(fHslider33);
		iSlow99 = iSlow4 * (fSlow53 == 2e+01);
		fSlow100 = InteractionPole_faustpower2_f(0.001 * fSlow38);
		fSlow101 = InteractionPole_faustpower2_f(fSlow65);
		fSlow102 = 1812812031.0501194 * fSlow101 * InteractionPole_faustpower2_f(fSlow100);
		fSlow103 = fSlow65 * fSlow100;
		fSlow104 = std::max<double>(1e-12, fSlow65 * (372.76953999999995 * (fSlow103 / (fSlow102 + 1.0)) + 0.0010995574287564276));
		fSlow105 = std::exp(fSlow23 * std::log(0.02 * ((iSlow26) ? ((iSlow32) ? ((iSlow35) ? 0.15 : ((iSlow36) ? 0.19 : 1.2)) : ((iSlow33) ? 1.38 : ((iSlow34) ? 121.15142662 : 391.146034516))) : ((iSlow27) ? ((iSlow30) ? 205.016 : ((iSlow31) ? 62.76 : 11.4)) : ((iSlow28) ? 429.0 : ((iSlow29) ? 329.0 : 5e+01))))) + fSlow24 * std::log(0.02 * ((iSlow12) ? ((iSlow18) ? ((iSlow21) ? 0.15 : ((iSlow22) ? 0.19 : 1.2)) : ((iSlow19) ? 1.38 : ((iSlow20) ? 121.15142662 : 391.146034516))) : ((iSlow13) ? ((iSlow16) ? 205.016 : ((iSlow17) ? 62.76 : 11.4)) : ((iSlow14) ? 429.0 : ((iSlow15) ? 329.0 : 5e+01))))));
		fSlow106 = InteractionPole_faustpower2_f(fSlow105);
		fSlow107 = InteractionPole_faustpower2_f(std::exp(fSlow23 * std::log(0.002631578947368421 * ((iSlow26) ? ((iSlow32) ? ((iSlow35) ? 1.6e+03 : ((iSlow36) ? 1.47e+03 : 8.3e+02)) : ((iSlow33) ? 740.568 : ((iSlow34) ? 376.812 : 385.1856))) : ((iSlow27) ? ((iSlow30) ? 878.64 : ((iSlow31) ? 460.24 : 522.3)) : ((iSlow28) ? 235.0 : ((iSlow29) ? 129.0 : 3.8e+02))))) + fSlow24 * std::log(0.002631578947368421 * ((iSlow12) ? ((iSlow18) ? ((iSlow21) ? 1.6e+03 : ((iSlow22) ? 1.47e+03 : 8.3e+02)) : ((iSlow19) ? 740.568 : ((iSlow20) ? 376.812 : 385.1856))) : ((iSlow13) ? ((iSlow16) ? 878.64 : ((iSlow17) ? 460.24 : 522.3)) : ((iSlow14) ? 235.0 : ((iSlow15) ? 129.0 : 3.8e+02)))))));
		fSlow108 = InteractionPole_faustpower2_f(fSlow37) * InteractionPole_faustpower2_f(fSlow63);
		fSlow109 = InteractionPole_faustpower2_f(fSlow52) * fSlow62 * fSlow63;
		fSlow110 = 0.0010995574287564276 * fSlow98 * std::exp(fSlow24 * std::log(2857.1428571428573 * ((iSlow12) ? ((iSlow18) ? ((iSlow21) ? 0.018 : ((iSlow22) ? 0.02 : 0.0002)) : ((iSlow19) ? 5e-05 : 0.00035)) : 0.00035)) + fSlow23 * std::log(2857.1428571428573 * ((iSlow26) ? ((iSlow32) ? ((iSlow35) ? 0.018 : ((iSlow36) ? 0.02 : 0.0002)) : ((iSlow33) ? 5e-05 : 0.00035)) : 0.00035)));
		fSlow111 = double(fHslider34);
		fSlow112 = double(fHslider35) * ((iSlow99 * (iSlow60 + (fSlow98 == 1.0) * iSlow58)) ? fSlow111 : std::max<double>(1e-06, fSlow111 + fSlow59 * std::min<double>(0.65 * fSlow111, fSlow104) / fSlow104 * (((iSlow99) ? fSlow65 * fSlow63 * (fSlow110 + 1289859999999.9998 * fSlow103 * (fSlow109 / (fSlow105 * (fSlow102 * (fSlow108 * fSlow107 / fSlow106) + 1.0)))) : fSlow65 * fSlow63 * fSlow56 * fSlow50 * (fSlow110 + 4.4e+03 * fSlow65 * fSlow48 * fSlow55 * InteractionPole_faustpower2_f(fSlow38) * (fSlow53 + 273.15) * InteractionPole_faustpower2_f(fSlow5) * (fSlow109 * InteractionPole_faustpower2_f(fSlow54) * fSlow56 * fSlow50 / (fSlow105 * (0.00181281203105012 * fSlow101 * InteractionPole_faustpower4_f(fSlow0) * InteractionPole_faustpower4_f(fSlow38) * InteractionPole_faustpower4_f(fSlow5) * (fSlow108 * InteractionPole_faustpower4_f(fSlow54) * InteractionPole_faustpower2_f(fSlow56) * InteractionPole_faustpower2_f(fSlow50) * fSlow107 / fSlow106) + 1.0))))) - fSlow104))) + double(fHslider32) * InteractionPole_faustpower2_f(double(fHslider31)) * (45.0 * std::sqrt(0.001 * std::max<double>(0.0, fSlow95)) + 25.0) + 2e+02 * (1.0 - fSlow97);
		fSlow113 = ((iSlow45) ? fSlow112 : fSlow112 + 0.6366197723675814 * fSlow92 * (std::max<double>(0.0, fSlow85 * (fSlow67 * (fSlow88 * fSlow90 - fSlow91 * fSlow86) / fSlow89)) / fSlow93));
		fSlow114 = std::exp(-(fConst5 * ((iSlow10) ? fSlow113 : fSlow113 + fSlow41 * (std::sqrt(std::max<double>(0.0, 3.141592653589793 * fSlow42 * double(fHslider30) * std::max<double>(1.0, fSlow94))) / fSlow39))));
		fSlow115 = 1.0 - double(fButton0);
	}
	virtual void compute(int count, FAUSTFLOAT** RESTRICT inputs, FAUSTFLOAT** RESTRICT outputs) {
		FAUSTFLOAT* input0 = inputs[0];
		FAUSTFLOAT* input1 = inputs[1];
		FAUSTFLOAT* input2 = inputs[2];
		FAUSTFLOAT* input3 = inputs[3];
		FAUSTFLOAT* input4 = inputs[4];
		FAUSTFLOAT* output0 = outputs[0];
		FAUSTFLOAT* output1 = outputs[1];
		for (int i0 = 0; i0 < count; i0 = i0 + 1) {
			double fTemp0 = fConst4 * std::min<double>(fConst1, std::max<double>(0.0, fSlow95 * (double(input4[i0]) + 1.0)));
			double fTemp1 = std::sin(fTemp0);
			double fTemp2 = std::cos(fTemp0);
			fRec0[0] = fSlow115 * fSlow114 * (fTemp2 * fRec0[1] - fTemp1 * fRec1[1]) + double(input0[i0]) * fSlow97 * fSlow8;
			fRec1[0] = fSlow115 * fSlow114 * (fRec0[1] * fTemp1 + fTemp2 * fRec1[1]) + double(input1[i0]) * fSlow97 * fSlow8;
			output0[i0] = FAUSTFLOAT(fRec0[0]);
			fRec2[0] = fSlow115 * fSlow114 * (fTemp2 * fRec2[1] - fTemp1 * fRec3[1]) + double(input2[i0]) * fSlow97 * fSlow8;
			fRec3[0] = fSlow115 * fSlow114 * (fTemp1 * fRec2[1] + fTemp2 * fRec3[1]) + double(input3[i0]) * fSlow97 * fSlow8;
			output1[i0] = FAUSTFLOAT(fRec2[0]);
			fRec0[1] = fRec0[0];
			fRec1[1] = fRec1[0];
			fRec2[1] = fRec2[0];
			fRec3[1] = fRec3[0];
		}
	}

 void executionCoefficients(double* z) const {
  z[0]=fSlow95;z[1]=fSlow115*fSlow114;z[2]=fSlow97;z[3]=fSlow8;z[4]=fConst4;z[5]=fConst1;
 }

};

#endif
