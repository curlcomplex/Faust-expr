/* ------------------------------------------------------------
name: "CYM-ID Thickness and Held Contact - experiment 02"
Code generated with Faust 2.70.3 (https://faust.grame.fr)
Compilation options: -lang cpp -ct 1 -cn CoefficientProbe -es 1 -mcd 16 -mdd 1024 -mdy 33 -double -ftz 0
------------------------------------------------------------ */

#ifndef  __CoefficientProbe_H__
#define  __CoefficientProbe_H__

#ifndef FAUSTFLOAT
#define FAUSTFLOAT float
#endif 

#include <algorithm>
#include <cmath>
#include <cstdint>
#include <math.h>

#ifndef FAUSTCLASS 
#define FAUSTCLASS CoefficientProbe
#endif

#ifdef __APPLE__ 
#define exp10f __exp10f
#define exp10 __exp10
#endif

#if defined(_WIN32)
#define RESTRICT __restrict
#else
#define RESTRICT __restrict__
#endif

static double CoefficientProbe_faustpower2_f(double value) {
	return value * value;
}
static double CoefficientProbe_faustpower3_f(double value) {
	return value * value * value;
}
static double CoefficientProbe_faustpower4_f(double value) {
	return value * value * value * value;
}

class CoefficientProbe : public dsp {
	
 private:
	
	FAUSTFLOAT fHslider0;
	FAUSTFLOAT fEntry0;
	FAUSTFLOAT fHslider1;
	FAUSTFLOAT fEntry1;
	FAUSTFLOAT fHslider2;
	FAUSTFLOAT fHslider3;
	FAUSTFLOAT fHslider4;
	FAUSTFLOAT fHslider5;
	FAUSTFLOAT fHslider6;
	FAUSTFLOAT fHslider7;
	FAUSTFLOAT fHslider8;
	FAUSTFLOAT fHslider9;
	FAUSTFLOAT fHslider10;
	FAUSTFLOAT fHslider11;
	FAUSTFLOAT fHslider12;
	FAUSTFLOAT fHslider13;
	FAUSTFLOAT fHslider14;
	FAUSTFLOAT fHslider15;
	FAUSTFLOAT fCheckbox0;
	FAUSTFLOAT fHslider16;
	FAUSTFLOAT fHslider17;
	FAUSTFLOAT fHslider18;
	FAUSTFLOAT fHslider19;
	FAUSTFLOAT fHslider20;
	FAUSTFLOAT fHslider21;
	FAUSTFLOAT fHslider22;
	FAUSTFLOAT fHslider23;
	FAUSTFLOAT fHslider24;
	FAUSTFLOAT fHslider25;
	FAUSTFLOAT fCheckbox1;
	FAUSTFLOAT fHslider26;
	FAUSTFLOAT fHslider27;
	FAUSTFLOAT fEntry2;
	FAUSTFLOAT fHslider28;
	FAUSTFLOAT fHslider29;
	FAUSTFLOAT fHslider30;
	FAUSTFLOAT fHslider31;
	FAUSTFLOAT fHslider32;
	FAUSTFLOAT fHslider33;
	FAUSTFLOAT fHslider34;
	FAUSTFLOAT fHslider35;
	FAUSTFLOAT fCheckbox2;
	int fSampleRate;
	double fConst1;
	double fConst2;
	double fConst3;
	
 public:
	CoefficientProbe() {}

	void metadata(Meta* m) { 
		m->declare("basics.lib/name", "Faust Basic Element Library");
		m->declare("basics.lib/tabulateNd", "Copyright (C) 2023 Bart Brouns <bart@magnetophon.nl>");
		m->declare("basics.lib/version", "1.12.0");
		m->declare("compile_options", "-lang cpp -ct 1 -cn CoefficientProbe -es 1 -mcd 16 -mdd 1024 -mdy 33 -double -ftz 0");
		m->declare("description", "Named elastic/thermal properties with explicitly unmeasured loss factors. Not validated replacement-material cymbal physics.");
		m->declare("filename", "coefficients.dsp");
		m->declare("maths.lib/author", "GRAME");
		m->declare("maths.lib/copyright", "GRAME");
		m->declare("maths.lib/license", "LGPL with exception");
		m->declare("maths.lib/name", "Faust Math Library");
		m->declare("maths.lib/version", "2.7.0");
		m->declare("name", "CYM-ID Thickness and Held Contact - experiment 02");
		m->declare("platform.lib/name", "Generic Platform Library");
		m->declare("platform.lib/version", "1.3.0");
	}

	virtual int getNumInputs() {
		return 0;
	}
	virtual int getNumOutputs() {
		return 5;
	}
	
	static void classInit(int sample_rate) {
	}
	
	virtual void instanceConstants(int sample_rate) {
		fSampleRate = sample_rate;
		double fConst0 = std::min<double>(1.92e+05, std::max<double>(1.0, double(fSampleRate)));
		fConst1 = 0.48 * fConst0;
		fConst2 = 25.0 / fConst0;
		fConst3 = 5e+01 / fConst0;
	}
	
	virtual void instanceResetUserInterface() {
		fHslider0 = FAUSTFLOAT(0.0);
		fEntry0 = FAUSTFLOAT(0.0);
		fHslider1 = FAUSTFLOAT(0.0);
		fEntry1 = FAUSTFLOAT(1.0);
		fHslider2 = FAUSTFLOAT(1.0);
		fHslider3 = FAUSTFLOAT(0.0);
		fHslider4 = FAUSTFLOAT(1.2);
		fHslider5 = FAUSTFLOAT(1.0);
		fHslider6 = FAUSTFLOAT(1.0);
		fHslider7 = FAUSTFLOAT(1.0);
		fHslider8 = FAUSTFLOAT(1.0);
		fHslider9 = FAUSTFLOAT(0.0);
		fHslider10 = FAUSTFLOAT(1.0);
		fHslider11 = FAUSTFLOAT(998.0);
		fHslider12 = FAUSTFLOAT(1.0);
		fHslider13 = FAUSTFLOAT(0.0);
		fHslider14 = FAUSTFLOAT(1.0);
		fHslider15 = FAUSTFLOAT(0.0);
		fCheckbox0 = FAUSTFLOAT(0.0);
		fHslider16 = FAUSTFLOAT(0.0);
		fHslider17 = FAUSTFLOAT(0.0);
		fHslider18 = FAUSTFLOAT(0.0);
		fHslider19 = FAUSTFLOAT(0.0);
		fHslider20 = FAUSTFLOAT(0.0);
		fHslider21 = FAUSTFLOAT(1.0);
		fHslider22 = FAUSTFLOAT(1.0);
		fHslider23 = FAUSTFLOAT(2e+01);
		fHslider24 = FAUSTFLOAT(1.0);
		fHslider25 = FAUSTFLOAT(1.0);
		fCheckbox1 = FAUSTFLOAT(0.0);
		fHslider26 = FAUSTFLOAT(1.0);
		fHslider27 = FAUSTFLOAT(1e+03);
		fEntry2 = FAUSTFLOAT(0.0);
		fHslider28 = FAUSTFLOAT(5.0);
		fHslider29 = FAUSTFLOAT(8.0);
		fHslider30 = FAUSTFLOAT(0.001002);
		fHslider31 = FAUSTFLOAT(1.0);
		fHslider32 = FAUSTFLOAT(1.0);
		fHslider33 = FAUSTFLOAT(1.0);
		fHslider34 = FAUSTFLOAT(0.0);
		fHslider35 = FAUSTFLOAT(1.0);
		fCheckbox2 = FAUSTFLOAT(0.0);
	}
	
	virtual void instanceClear() {
	}
	
	virtual void init(int sample_rate) {
		classInit(sample_rate);
		instanceInit(sample_rate);
	}
	
	virtual void instanceInit(int sample_rate) {
		instanceConstants(sample_rate);
		instanceResetUserInterface();
		instanceClear();
	}
	
	virtual CoefficientProbe* clone() {
		return new CoefficientProbe();
	}
	
	virtual int getSampleRate() {
		return fSampleRate;
	}
	
	virtual void buildUserInterface(UI* ui_interface) {
		ui_interface->openVerticalBox("CYM-ID Thickness and Held Contact - experiment 02");
		ui_interface->addHorizontalSlider("b0", &fHslider21, FAUSTFLOAT(1.0), FAUSTFLOAT(0.0), FAUSTFLOAT(1.0), FAUSTFLOAT(1e-08));
		ui_interface->addHorizontalSlider("b1", &fHslider20, FAUSTFLOAT(0.0), FAUSTFLOAT(0.0), FAUSTFLOAT(1.0), FAUSTFLOAT(1e-08));
		ui_interface->addHorizontalSlider("b2", &fHslider19, FAUSTFLOAT(0.0), FAUSTFLOAT(0.0), FAUSTFLOAT(1.0), FAUSTFLOAT(1e-08));
		ui_interface->addHorizontalSlider("b3", &fHslider18, FAUSTFLOAT(0.0), FAUSTFLOAT(0.0), FAUSTFLOAT(1.0), FAUSTFLOAT(1e-08));
		ui_interface->addHorizontalSlider("c0", &fHslider17, FAUSTFLOAT(0.0), FAUSTFLOAT(0.0), FAUSTFLOAT(1.0), FAUSTFLOAT(1e-08));
		ui_interface->addHorizontalSlider("c1", &fHslider16, FAUSTFLOAT(0.0), FAUSTFLOAT(0.0), FAUSTFLOAT(1.0), FAUSTFLOAT(1e-08));
		ui_interface->declare(&fHslider29, "unit", "cm2");
		ui_interface->addHorizontalSlider("contact_area_cm2", &fHslider29, FAUSTFLOAT(8.0), FAUSTFLOAT(0.5), FAUSTFLOAT(6e+01), FAUSTFLOAT(0.01));
		ui_interface->declare(&fEntry2, "style", "menu{'Fingertip/palm-like':0;'Felt pad':1;'Fabric pad':2;'Leather pad':3;'Rubber pad':4;'Wood held block':5;'Bone-like held piece':6}");
		ui_interface->addNumEntry("contact_material", &fEntry2, FAUSTFLOAT(0.0), FAUSTFLOAT(0.0), FAUSTFLOAT(6.0), FAUSTFLOAT(1.0));
		ui_interface->declare(&fHslider28, "unit", "mm");
		ui_interface->addHorizontalSlider("contact_pad_mm", &fHslider28, FAUSTFLOAT(5.0), FAUSTFLOAT(0.2), FAUSTFLOAT(3e+01), FAUSTFLOAT(0.01));
		ui_interface->addHorizontalSlider("contact_pressure", &fHslider15, FAUSTFLOAT(0.0), FAUSTFLOAT(0.0), FAUSTFLOAT(1.0), FAUSTFLOAT(0.001));
		ui_interface->addHorizontalSlider("contact_strength", &fHslider14, FAUSTFLOAT(1.0), FAUSTFLOAT(0.0), FAUSTFLOAT(4.0), FAUSTFLOAT(0.001));
		ui_interface->addHorizontalSlider("d", &fHslider32, FAUSTFLOAT(1.0), FAUSTFLOAT(1e-06), FAUSTFLOAT(1e+04), FAUSTFLOAT(1e-06));
		ui_interface->addHorizontalSlider("diameter_ratio", &fHslider12, FAUSTFLOAT(1.0), FAUSTFLOAT(0.4), FAUSTFLOAT(2.5), FAUSTFLOAT(0.0001));
		ui_interface->addCheckButton("external_excitation", &fCheckbox2);
		ui_interface->addHorizontalSlider("f", &fHslider27, FAUSTFLOAT(1e+03), FAUSTFLOAT(1.0), FAUSTFLOAT(1e+05), FAUSTFLOAT(1e-06));
		ui_interface->addHorizontalSlider("fluid_density", &fHslider11, FAUSTFLOAT(998.0), FAUSTFLOAT(0.1), FAUSTFLOAT(2e+04), FAUSTFLOAT(0.01));
		ui_interface->addHorizontalSlider("fluid_viscosity", &fHslider30, FAUSTFLOAT(0.001002), FAUSTFLOAT(1e-07), FAUSTFLOAT(2.0), FAUSTFLOAT(1e-06));
		ui_interface->declare(&fHslider26, "scale", "log");
		ui_interface->addHorizontalSlider("frequency_scale", &fHslider26, FAUSTFLOAT(1.0), FAUSTFLOAT(0.125), FAUSTFLOAT(8.0), FAUSTFLOAT(0.001));
		ui_interface->addHorizontalSlider("geometry_compensation", &fHslider22, FAUSTFLOAT(1.0), FAUSTFLOAT(0.01), FAUSTFLOAT(1e+02), FAUSTFLOAT(1e-06));
		ui_interface->addCheckButton("geometry_pitch_compensate", &fCheckbox0);
		ui_interface->addHorizontalSlider("grip", &fHslider34, FAUSTFLOAT(0.0), FAUSTFLOAT(0.0), FAUSTFLOAT(1.0), FAUSTFLOAT(0.001));
		ui_interface->addHorizontalSlider("grip_strength", &fHslider35, FAUSTFLOAT(1.0), FAUSTFLOAT(0.1), FAUSTFLOAT(4.0), FAUSTFLOAT(0.001));
		ui_interface->addHorizontalSlider("hydro", &fHslider13, FAUSTFLOAT(0.0), FAUSTFLOAT(0.0), FAUSTFLOAT(2.0), FAUSTFLOAT(1e-08));
		ui_interface->addHorizontalSlider("immersion", &fHslider0, FAUSTFLOAT(0.0), FAUSTFLOAT(0.0), FAUSTFLOAT(1.0), FAUSTFLOAT(1e-05));
		ui_interface->declare(&fHslider31, "scale", "log");
		ui_interface->addHorizontalSlider("intrinsic_loss_scale", &fHslider31, FAUSTFLOAT(1.0), FAUSTFLOAT(0.1), FAUSTFLOAT(1e+01), FAUSTFLOAT(0.001));
		ui_interface->declare(&fHslider33, "scale", "log");
		ui_interface->addHorizontalSlider("loss_scale", &fHslider33, FAUSTFLOAT(1.0), FAUSTFLOAT(0.25), FAUSTFLOAT(8.0), FAUSTFLOAT(0.001));
		ui_interface->addHorizontalSlider("mass_edge", &fHslider3, FAUSTFLOAT(0.0), FAUSTFLOAT(0.0), FAUSTFLOAT(1.0), FAUSTFLOAT(1e-08));
		ui_interface->declare(&fEntry0, "style", "menu{'Original / bronze reference':0;'Gold (pure)':1;'Silver (pure)':2;'Titanium':3;'Steel (carbon)':4;'Aluminium':5;'Copper (C11000)':6;'Brass (C26000)':7;'Glass (fused silica)':8;'Glass (borosilicate)':9;'Acrylic (PMMA)':10;'Wood (effective)':11}");
		ui_interface->addNumEntry("material_a", &fEntry0, FAUSTFLOAT(0.0), FAUSTFLOAT(0.0), FAUSTFLOAT(11.0), FAUSTFLOAT(1.0));
		ui_interface->declare(&fEntry1, "style", "menu{'Original / bronze reference':0;'Gold (pure)':1;'Silver (pure)':2;'Titanium':3;'Steel (carbon)':4;'Aluminium':5;'Copper (C11000)':6;'Brass (C26000)':7;'Glass (fused silica)':8;'Glass (borosilicate)':9;'Acrylic (PMMA)':10;'Wood (effective)':11}");
		ui_interface->addNumEntry("material_b", &fEntry1, FAUSTFLOAT(1.0), FAUSTFLOAT(0.0), FAUSTFLOAT(11.0), FAUSTFLOAT(1.0));
		ui_interface->addHorizontalSlider("material_depth", &fHslider25, FAUSTFLOAT(1.0), FAUSTFLOAT(0.0), FAUSTFLOAT(1.0), FAUSTFLOAT(0.001));
		ui_interface->addHorizontalSlider("material_mix", &fHslider1, FAUSTFLOAT(0.0), FAUSTFLOAT(0.0), FAUSTFLOAT(1.0), FAUSTFLOAT(0.001));
		ui_interface->addCheckButton("pitch_lock", &fCheckbox1);
		ui_interface->declare(&fHslider2, "scale", "log");
		ui_interface->addHorizontalSlider("rim_thickness_ratio", &fHslider2, FAUSTFLOAT(1.0), FAUSTFLOAT(0.25), FAUSTFLOAT(4.0), FAUSTFLOAT(0.001));
		ui_interface->addHorizontalSlider("temperature_C", &fHslider23, FAUSTFLOAT(2e+01), FAUSTFLOAT(-1.5e+02), FAUSTFLOAT(1e+02), FAUSTFLOAT(0.1));
		ui_interface->addHorizontalSlider("thermal_modulus_ratio", &fHslider24, FAUSTFLOAT(1.0), FAUSTFLOAT(0.02), FAUSTFLOAT(2.0), FAUSTFLOAT(1e-06));
		ui_interface->declare(&fHslider4, "unit", "mm");
		ui_interface->addHorizontalSlider("thermal_thickness_mm", &fHslider4, FAUSTFLOAT(1.2), FAUSTFLOAT(0.2), FAUSTFLOAT(6.0), FAUSTFLOAT(0.01));
		ui_interface->declare(&fHslider5, "scale", "log");
		ui_interface->addHorizontalSlider("thickness_ratio", &fHslider5, FAUSTFLOAT(1.0), FAUSTFLOAT(0.125), FAUSTFLOAT(8.0), FAUSTFLOAT(0.001));
		ui_interface->addHorizontalSlider("wet0", &fHslider9, FAUSTFLOAT(0.0), FAUSTFLOAT(0.0), FAUSTFLOAT(2.0), FAUSTFLOAT(1e-08));
		ui_interface->addHorizontalSlider("wet1", &fHslider8, FAUSTFLOAT(1.0), FAUSTFLOAT(0.0), FAUSTFLOAT(2.0), FAUSTFLOAT(1e-08));
		ui_interface->addHorizontalSlider("wet2", &fHslider7, FAUSTFLOAT(1.0), FAUSTFLOAT(0.0), FAUSTFLOAT(2.0), FAUSTFLOAT(1e-08));
		ui_interface->addHorizontalSlider("wet3", &fHslider6, FAUSTFLOAT(1.0), FAUSTFLOAT(0.0), FAUSTFLOAT(2.0), FAUSTFLOAT(1e-08));
		ui_interface->addHorizontalSlider("wet4", &fHslider10, FAUSTFLOAT(1.0), FAUSTFLOAT(0.0), FAUSTFLOAT(2.0), FAUSTFLOAT(1e-08));
		ui_interface->closeBox();
	}
	
	virtual void compute(int count, FAUSTFLOAT** RESTRICT inputs, FAUSTFLOAT** RESTRICT outputs) {
		FAUSTFLOAT* output0 = outputs[0];
		FAUSTFLOAT* output1 = outputs[1];
		FAUSTFLOAT* output2 = outputs[2];
		FAUSTFLOAT* output3 = outputs[3];
		FAUSTFLOAT* output4 = outputs[4];
		double fSlow0 = double(fHslider0);
		int iSlow1 = fSlow0 == 0.0;
		int iSlow2 = int(double(fEntry0));
		int iSlow3 = iSlow2 >= 6;
		int iSlow4 = iSlow2 >= 3;
		int iSlow5 = iSlow2 >= 2;
		int iSlow6 = iSlow2 >= 1;
		int iSlow7 = iSlow2 >= 5;
		int iSlow8 = iSlow2 >= 4;
		int iSlow9 = iSlow2 >= 9;
		int iSlow10 = iSlow2 >= 8;
		int iSlow11 = iSlow2 >= 7;
		int iSlow12 = iSlow2 >= 11;
		int iSlow13 = iSlow2 >= 10;
		double fSlow14 = double(fHslider1);
		double fSlow15 = 1.0 - fSlow14;
		int iSlow16 = int(double(fEntry1));
		int iSlow17 = iSlow16 >= 6;
		int iSlow18 = iSlow16 >= 3;
		int iSlow19 = iSlow16 >= 2;
		int iSlow20 = iSlow16 >= 1;
		int iSlow21 = iSlow16 >= 5;
		int iSlow22 = iSlow16 >= 4;
		int iSlow23 = iSlow16 >= 9;
		int iSlow24 = iSlow16 >= 8;
		int iSlow25 = iSlow16 >= 7;
		int iSlow26 = iSlow16 >= 11;
		int iSlow27 = iSlow16 >= 10;
		double fSlow28 = std::exp(fSlow14 * std::log(0.00011363636363636364 * ((iSlow17) ? ((iSlow23) ? ((iSlow26) ? 7e+02 : ((iSlow27) ? 1.19e+03 : 2.23e+03)) : ((iSlow24) ? 2.2e+03 : ((iSlow25) ? 8.53e+03 : 8.91e+03))) : ((iSlow18) ? ((iSlow21) ? 2.7e+03 : ((iSlow22) ? 7.85e+03 : 4.51e+03)) : ((iSlow19) ? 1.049e+04 : ((iSlow20) ? 19325.0 : 8.8e+03))))) + fSlow15 * std::log(0.00011363636363636364 * ((iSlow3) ? ((iSlow9) ? ((iSlow12) ? 7e+02 : ((iSlow13) ? 1.19e+03 : 2.23e+03)) : ((iSlow10) ? 2.2e+03 : ((iSlow11) ? 8.53e+03 : 8.91e+03))) : ((iSlow4) ? ((iSlow7) ? 2.7e+03 : ((iSlow8) ? 7.85e+03 : 4.51e+03)) : ((iSlow5) ? 1.049e+04 : ((iSlow6) ? 19325.0 : 8.8e+03))))));
		double fSlow29 = double(fHslider2);
		double fSlow30 = double(fHslider3) * (fSlow29 + -1.0) + 1.0;
		double fSlow31 = double(fHslider4);
		double fSlow32 = double(fHslider5);
		double fSlow33 = std::max<double>(1e-12, 8.8 * fSlow32 * fSlow31 * fSlow30 * fSlow28);
		double fSlow34 = 1.0 - fSlow0;
		double fSlow35 = std::max<double>(0.0, std::min<double>(1.0, double(fHslider10) * CoefficientProbe_faustpower4_f(fSlow0) + double(fHslider9) * CoefficientProbe_faustpower4_f(fSlow34) + fSlow0 * (4.0 * double(fHslider8) * CoefficientProbe_faustpower3_f(fSlow34) + fSlow0 * (6.0 * double(fHslider7) * CoefficientProbe_faustpower2_f(fSlow34) + 4.0 * double(fHslider6) * fSlow0 * fSlow34))));
		double fSlow36 = double(fHslider11);
		double fSlow37 = double(fHslider12);
		double fSlow38 = std::max<double>(0.0, 0.25 * double(fHslider13) * fSlow37 * fSlow36 * fSlow35 / fSlow33);
		double fSlow39 = double(fHslider14);
		double fSlow40 = double(fHslider15);
		int iSlow41 = (fSlow40 < 1e-12) + (fSlow39 == 0.0);
		int iSlow42 = fSlow37 == 1.0;
		int iSlow43 = iSlow42 * (fSlow29 == 1.0) * (fSlow32 == 1.0);
		double fSlow44 = CoefficientProbe_faustpower2_f(fSlow37);
		double fSlow45 = double(fHslider16) * fSlow29;
		double fSlow46 = double(fHslider17);
		double fSlow47 = CoefficientProbe_faustpower2_f(fSlow32);
		double fSlow48 = fSlow47 * (double(fHslider21) + fSlow29 * (double(fHslider20) + fSlow29 * (double(fHslider19) + double(fHslider18) * fSlow29)));
		double fSlow49 = ((iSlow43) ? 1.0 : ((iSlow42) ? std::sqrt(std::max<double>(1e-12, (fSlow45 + fSlow46 + fSlow48) / fSlow30)) : std::sqrt(std::max<double>(1e-12, (fSlow48 / CoefficientProbe_faustpower4_f(fSlow37) + (fSlow46 + fSlow45) / fSlow44) / fSlow30))));
		double fSlow50 = ((iSlow3) ? ((iSlow9) ? ((iSlow12) ? 5e-06 : ((iSlow13) ? 8e-05 : 3.25e-06)) : ((iSlow10) ? 5.7e-07 : ((iSlow11) ? 1.9980000000000002e-05 : 1.692e-05))) : ((iSlow4) ? ((iSlow7) ? 2.3e-05 : ((iSlow8) ? 1.2e-05 : 8.41e-06)) : ((iSlow5) ? 1.89e-05 : ((iSlow6) ? 1.4e-05 : 1.7e-05))));
		double fSlow51 = fSlow50 + fSlow14 * (((iSlow17) ? ((iSlow23) ? ((iSlow26) ? 5e-06 : ((iSlow27) ? 8e-05 : 3.25e-06)) : ((iSlow24) ? 5.7e-07 : ((iSlow25) ? 1.9980000000000002e-05 : 1.692e-05))) : ((iSlow18) ? ((iSlow21) ? 2.3e-05 : ((iSlow22) ? 1.2e-05 : 8.41e-06)) : ((iSlow19) ? 1.89e-05 : ((iSlow20) ? 1.4e-05 : 1.7e-05)))) - fSlow50);
		double fSlow52 = double(fHslider23);
		double fSlow53 = std::max<double>(0.1, (fSlow52 + -2e+01) * fSlow51 + 1.0);
		double fSlow54 = double(fHslider24);
		double fSlow55 = std::sqrt(fSlow54 * fSlow53);
		int iSlow56 = iSlow2 == 0;
		int iSlow57 = (iSlow56 * (fSlow14 == 0.0) + (iSlow16 == 0) * (iSlow56 + (fSlow14 == 1.0))) > 0;
		double fSlow58 = double(fHslider25);
		int iSlow59 = fSlow58 == 0.0;
		double fSlow60 = ((iSlow3) ? ((iSlow9) ? ((iSlow12) ? 0.3 : ((iSlow13) ? 0.35 : 0.2)) : ((iSlow10) ? 0.17 : ((iSlow11) ? 0.33333333333333326 : 0.328125))) : ((iSlow4) ? ((iSlow7) ? 0.33 : ((iSlow8) ? 0.3 : 0.361)) : ((iSlow5) ? 0.37 : ((iSlow6) ? 0.44 : 0.34))));
		double fSlow61 = std::exp(fSlow14 * std::log(9.09090909090909e-12 * ((iSlow17) ? ((iSlow23) ? ((iSlow26) ? 3.2e+09 : ((iSlow27) ? 3.3e+09 : 6.4e+10)) : ((iSlow24) ? 7.17e+10 : ((iSlow25) ? 110316116688.0 : 117210873981.0))) : ((iSlow18) ? ((iSlow21) ? 6.91e+10 : ((iSlow22) ? 2.058e+11 : 1.2e+11)) : ((iSlow19) ? 8.3e+10 : ((iSlow20) ? 7.8e+10 : 1.1e+11))))) + fSlow15 * std::log(9.09090909090909e-12 * ((iSlow3) ? ((iSlow9) ? ((iSlow12) ? 3.2e+09 : ((iSlow13) ? 3.3e+09 : 6.4e+10)) : ((iSlow10) ? 7.17e+10 : ((iSlow11) ? 110316116688.0 : 117210873981.0))) : ((iSlow4) ? ((iSlow7) ? 6.91e+10 : ((iSlow8) ? 2.058e+11 : 1.2e+11)) : ((iSlow5) ? 8.3e+10 : ((iSlow6) ? 7.8e+10 : 1.1e+11))))));
		double fSlow62 = std::exp(fSlow58 * std::log(std::sqrt(0.8844 * (fSlow61 / (fSlow28 * (1.0 - CoefficientProbe_faustpower2_f(fSlow60 + fSlow14 * (((iSlow17) ? ((iSlow23) ? ((iSlow26) ? 0.3 : ((iSlow27) ? 0.35 : 0.2)) : ((iSlow24) ? 0.17 : ((iSlow25) ? 0.33333333333333326 : 0.328125))) : ((iSlow18) ? ((iSlow21) ? 0.33 : ((iSlow22) ? 0.3 : 0.361)) : ((iSlow19) ? 0.37 : ((iSlow20) ? 0.44 : 0.34)))) - fSlow60))))))));
		double fSlow63 = (((double(fCheckbox1) + double(iSlow59) + double(iSlow57)) > 0.0) ? 1.0 : fSlow62) * fSlow55;
		double fSlow64 = double(fHslider27);
		double fSlow65 = fSlow64 * double(fHslider26);
		double fSlow66 = ((iSlow43) ? fSlow65 * fSlow63 : fSlow65 * fSlow63 * ((int(double(fCheckbox0))) ? double(fHslider22) * fSlow49 : fSlow49));
		double fSlow67 = CoefficientProbe_faustpower2_f(fSlow66);
		int iSlow68 = int(double(fEntry2));
		int iSlow69 = iSlow68 >= 4;
		int iSlow70 = iSlow68 >= 2;
		int iSlow71 = iSlow68 >= 1;
		int iSlow72 = iSlow68 >= 3;
		int iSlow73 = iSlow68 >= 6;
		int iSlow74 = iSlow68 >= 5;
		double fSlow75 = ((iSlow69) ? ((iSlow73) ? 3e-05 : ((iSlow74) ? 3e-05 : 4e-05)) : ((iSlow70) ? ((iSlow72) ? 3e-05 : 0.00015) : ((iSlow71) ? 8e-05 : 0.0002)));
		double fSlow76 = CoefficientProbe_faustpower2_f(fSlow75);
		double fSlow77 = 39.47841760435743 * fSlow76 * fSlow67 + 1.0;
		double fSlow78 = ((iSlow69) ? ((iSlow73) ? 4e+08 : ((iSlow74) ? 3e+08 : 3e+06)) : ((iSlow70) ? ((iSlow72) ? 2e+06 : 6e+04) : ((iSlow71) ? 1.5e+05 : 3e+05)));
		double fSlow79 = ((iSlow69) ? 0.001 : ((iSlow70) ? ((iSlow72) ? 0.001 : 0.004) : ((iSlow71) ? 0.002 : 0.006)));
		double fSlow80 = CoefficientProbe_faustpower2_f(fSlow79);
		double fSlow81 = 39.47841760435743 * fSlow67 * fSlow80 + 1.0;
		double fSlow82 = ((iSlow69) ? ((iSlow73) ? 1.5e+08 : ((iSlow74) ? 1e+08 : 2e+06)) : ((iSlow70) ? ((iSlow72) ? 1e+06 : 2.5e+04) : ((iSlow71) ? 6e+04 : 2e+05)));
		double fSlow83 = fSlow82 * fSlow79 / fSlow81 + fSlow75 * fSlow78 / fSlow77;
		double fSlow84 = double(fHslider29) / double(fHslider28);
		double fSlow85 = 0.6283185307179586 * fSlow84 * fSlow83 + 75.39822368615503;
		double fSlow86 = ((iSlow69) ? ((iSlow73) ? 1.5e+10 : ((iSlow74) ? 1e+10 : 1.5e+06)) : ((iSlow70) ? ((iSlow72) ? 3e+06 : 5e+03) : ((iSlow71) ? 3e+04 : 8e+04))) + 39.47841760435743 * fSlow67 * (fSlow82 * fSlow80 / fSlow81 + fSlow76 * fSlow78 / fSlow77);
		double fSlow87 = 0.1 * fSlow84 * fSlow86 + 1e+05;
		double fSlow88 = CoefficientProbe_faustpower2_f(fSlow87) + fSlow67 * CoefficientProbe_faustpower2_f(fSlow85);
		double fSlow89 = 7.5398223686155035 * fSlow86 + 62831.853071795864 * fSlow83;
		double fSlow90 = 1e+04 * fSlow86 - 47.37410112522892 * fSlow67 * fSlow83;
		double fSlow91 = fSlow32 * fSlow44 * fSlow30;
		double fSlow92 = fSlow39 * CoefficientProbe_faustpower2_f(fSlow40) / fSlow91;
		double fSlow93 = std::max<double>(1.0, fSlow66);
		double fSlow94 = ((iSlow41) ? fSlow66 : 0.15915494309189535 * std::sqrt(39.47841760435743 * CoefficientProbe_faustpower2_f(fSlow93) + 8.0 * fSlow92 * std::max<double>(0.0, fSlow84 * ((fSlow90 * fSlow87 + fSlow67 * fSlow89 * fSlow85) / fSlow88))));
		double fSlow95 = ((iSlow1) ? fSlow94 : fSlow94 / std::sqrt(fSlow38 + 1.0));
		double fSlow96 = double(fHslider31);
		int iSlow97 = iSlow43 * (fSlow52 == 2e+01);
		double fSlow98 = CoefficientProbe_faustpower2_f(0.001 * fSlow31);
		double fSlow99 = CoefficientProbe_faustpower2_f(fSlow64);
		double fSlow100 = 1812812031.0501194 * fSlow99 * CoefficientProbe_faustpower2_f(fSlow98);
		double fSlow101 = fSlow64 * fSlow98;
		double fSlow102 = std::max<double>(1e-12, fSlow64 * (372.76953999999995 * (fSlow101 / (fSlow100 + 1.0)) + 0.0010995574287564276));
		double fSlow103 = std::exp(fSlow14 * std::log(0.02 * ((iSlow17) ? ((iSlow23) ? ((iSlow26) ? 0.15 : ((iSlow27) ? 0.19 : 1.2)) : ((iSlow24) ? 1.38 : ((iSlow25) ? 121.15142662 : 391.146034516))) : ((iSlow18) ? ((iSlow21) ? 205.016 : ((iSlow22) ? 62.76 : 11.4)) : ((iSlow19) ? 429.0 : ((iSlow20) ? 329.0 : 5e+01))))) + fSlow15 * std::log(0.02 * ((iSlow3) ? ((iSlow9) ? ((iSlow12) ? 0.15 : ((iSlow13) ? 0.19 : 1.2)) : ((iSlow10) ? 1.38 : ((iSlow11) ? 121.15142662 : 391.146034516))) : ((iSlow4) ? ((iSlow7) ? 205.016 : ((iSlow8) ? 62.76 : 11.4)) : ((iSlow5) ? 429.0 : ((iSlow6) ? 329.0 : 5e+01))))));
		double fSlow104 = CoefficientProbe_faustpower2_f(fSlow103);
		double fSlow105 = CoefficientProbe_faustpower2_f(std::exp(fSlow14 * std::log(0.002631578947368421 * ((iSlow17) ? ((iSlow23) ? ((iSlow26) ? 1.6e+03 : ((iSlow27) ? 1.47e+03 : 8.3e+02)) : ((iSlow24) ? 740.568 : ((iSlow25) ? 376.812 : 385.1856))) : ((iSlow18) ? ((iSlow21) ? 878.64 : ((iSlow22) ? 460.24 : 522.3)) : ((iSlow19) ? 235.0 : ((iSlow20) ? 129.0 : 3.8e+02))))) + fSlow15 * std::log(0.002631578947368421 * ((iSlow3) ? ((iSlow9) ? ((iSlow12) ? 1.6e+03 : ((iSlow13) ? 1.47e+03 : 8.3e+02)) : ((iSlow10) ? 740.568 : ((iSlow11) ? 376.812 : 385.1856))) : ((iSlow4) ? ((iSlow7) ? 878.64 : ((iSlow8) ? 460.24 : 522.3)) : ((iSlow5) ? 235.0 : ((iSlow6) ? 129.0 : 3.8e+02)))))));
		double fSlow106 = CoefficientProbe_faustpower2_f(fSlow28) * CoefficientProbe_faustpower2_f(fSlow62);
		double fSlow107 = CoefficientProbe_faustpower2_f(fSlow51) * fSlow61 * fSlow62;
		double fSlow108 = 0.0010995574287564276 * fSlow96 * std::exp(fSlow15 * std::log(2857.1428571428573 * ((iSlow3) ? ((iSlow9) ? ((iSlow12) ? 0.018 : ((iSlow13) ? 0.02 : 0.0002)) : ((iSlow10) ? 5e-05 : 0.00035)) : 0.00035)) + fSlow14 * std::log(2857.1428571428573 * ((iSlow17) ? ((iSlow23) ? ((iSlow26) ? 0.018 : ((iSlow27) ? 0.02 : 0.0002)) : ((iSlow24) ? 5e-05 : 0.00035)) : 0.00035)));
		double fSlow109 = double(fHslider32);
		double fSlow110 = double(fHslider33) * ((iSlow97 * (iSlow59 + (fSlow96 == 1.0) * iSlow57)) ? fSlow109 : std::max<double>(1e-06, fSlow109 + fSlow58 * std::min<double>(0.65 * fSlow109, fSlow102) / fSlow102 * (((iSlow97) ? fSlow64 * fSlow62 * (fSlow108 + 1289859999999.9998 * fSlow101 * (fSlow107 / (fSlow103 * (fSlow100 * (fSlow106 * fSlow105 / fSlow104) + 1.0)))) : fSlow64 * fSlow62 * fSlow55 * fSlow49 * (fSlow108 + 4.4e+03 * fSlow64 * fSlow47 * fSlow54 * CoefficientProbe_faustpower2_f(fSlow31) * (fSlow52 + 273.15) * CoefficientProbe_faustpower2_f(fSlow30) * (fSlow107 * CoefficientProbe_faustpower2_f(fSlow53) * fSlow55 * fSlow49 / (fSlow103 * (0.00181281203105012 * fSlow99 * CoefficientProbe_faustpower4_f(fSlow32) * CoefficientProbe_faustpower4_f(fSlow31) * CoefficientProbe_faustpower4_f(fSlow30) * (fSlow106 * CoefficientProbe_faustpower4_f(fSlow53) * CoefficientProbe_faustpower2_f(fSlow55) * CoefficientProbe_faustpower2_f(fSlow49) * fSlow105 / fSlow104) + 1.0))))) - fSlow102)));
		double fSlow111 = double(fHslider35) * CoefficientProbe_faustpower2_f(double(fHslider34)) * (45.0 * std::sqrt(0.001 * std::max<double>(0.0, fSlow95)) + 25.0);
		double fSlow112 = fConst1 - fSlow95;
		double fSlow113 = ((int(double(fCheckbox2))) ? std::min<double>(1.0, std::max<double>(0.0, fConst3 * fSlow112)) : std::min<double>(1.0, std::max<double>(0.0, fConst2 * fSlow112)));
		double fSlow114 = 2e+02 * (1.0 - fSlow113);
		double fSlow115 = ((iSlow41) ? fSlow110 + fSlow111 + fSlow114 : fSlow114 + fSlow111 + fSlow110 + 0.6366197723675814 * fSlow92 * (std::max<double>(0.0, fSlow84 * (fSlow66 * (fSlow87 * fSlow89 - fSlow90 * fSlow85) / fSlow88)) / fSlow93));
		double fSlow116 = ((iSlow1) ? fSlow115 : fSlow115 + fSlow35 * (std::sqrt(std::max<double>(0.0, 3.141592653589793 * fSlow36 * double(fHslider30) * std::max<double>(1.0, fSlow94))) / fSlow33));
		double fSlow117 = ((iSlow43) ? 1.0 : 1.0 / std::max<double>(0.001, fSlow91));
		for (int i0 = 0; i0 < count; i0 = i0 + 1) {
			output0[i0] = FAUSTFLOAT(fSlow95);
			output1[i0] = FAUSTFLOAT(fSlow116);
			output2[i0] = FAUSTFLOAT(fSlow117);
			output3[i0] = FAUSTFLOAT(fSlow113);
			output4[i0] = FAUSTFLOAT(fSlow38);
		}
	}

};

#endif
